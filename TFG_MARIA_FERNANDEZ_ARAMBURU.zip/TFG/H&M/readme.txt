REQUIREMENTS:
    - npm/nodejs (tested with versions npm: 8.1.2, nodejs: 16.13.2)


From this directory:

INSTALL DEPENDENCIES (run once):
    npm install

START ENVIRONMENT:
    node .

Server should now be running on localhost:3000