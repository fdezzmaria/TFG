const express = require("express");
const path = require("path");
const app = express();

// Express Middleware for serving static files
app.use(express.static(path.join(__dirname, 'public')));

app.get("/", function (req, res) {
    res.redirect("/index.html");
});
app.listen(3000, function () {
    console.log("Server is running on localhost:3000");
});