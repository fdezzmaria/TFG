var tfg = tfg || {};

tfg.antenna = tfg.antenna || (function () {
    

    return {
        getCurrentEPCs: function() {
            var epcs = [];

            var xml = tfg.utility.httpGet("http://192.168.7.2/devices/AdvanPay-cf-us-120/jsonMinLocation");
            var dom = tfg.utility.parseXml(xml);
            var json = tfg.utility.xml2json(dom,"");
            var j = JSON.parse(json);
            
            if(j.response && j.response.data && j.response.data.result) {
                var jr = JSON.parse(j.response.data.result);
                jr.forEach(e => {
                    if(e.epc) epcs.push(e.epc);
                });
            };
            return epcs;
        },

        getCurrentEANs: function() {
            var eans = [];

            var epcs = this.getCurrentEPCs();
            epcs.forEach(epc => {
                var ean = keonn.epc.getGtinForEpc(epc);
                if(ean && !eans.includes(ean)) eans.push(ean);
            })
            return eans;
        }
    }

})();