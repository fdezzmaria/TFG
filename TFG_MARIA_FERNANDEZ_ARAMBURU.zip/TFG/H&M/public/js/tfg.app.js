var tfg = tfg || {};

tfg.app = tfg.app || (function () {
    var MPSDK = null;
    var inventory;
    var catalog = {};
    // var currentItemsToShow = {};
    var eansToShow = [];
    var selectedItemIndex = null;
    var viewMode = null;

    var showCoords = false;


    const BLUE_TAG = {r: 0.0, g: 0.3, b: 0.7};
    const BLUE_TAG_SEL = {r: 0.0, g: 0.9, b: 0.9};
    const RED_TAG = {r: 0.7, g: 0.2, b: 0.0};
    const RED_TAG_SEL = {r: 0.9, g: 0.9, b: 0.1};

    
    async function fetchData(code) { // EXPLICAR
        const url = "https://testing.keonn.com/advancloud/publish/productsimplelist/testmaria";
        const data = {
            "requests": [
                {"code": code} 
            ]
        };
    
        const response = await fetch(url, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    
        if (!response.ok) {
            const errorMessage = `An error occurred: ${response.status}`;
            throw new Error(errorMessage);
        }
    
        const responseData = await response.json();
    
        return responseData.resultdata.list;

    }

    function getInfoForInfo(ean, info) { // EXPLICAR

        var title = info.data.name != "" ? info.data.name : "No title";
        var image = info.data.imageUrlMainPart != "" && info.data.imageUrlMainPart != "NO_IMAGE_FOUND" ? info.data.imageUrlMainPart : "https://cutewallpaper.org/24/image-placeholder-png/index-of-assetsimg.png";
        var price = "X€";
        //var size = info.data.size != "" ? info.data.size : "No title";

        console.log('quantity',inventory[ean]['info']['quantity']);
        console.log('productid', info.data.productid);

        return {
            "title": title,
            "image": image,
            "price": price,
            "quantity": inventory[ean]['info']['quantity'], // added
            "productid": info.data.productid,
            //"size": size
        }
    }


    function updateInventory(eans){ // EXPLICAR

        eans.forEach(async ean =>{

            try{

                console.log('ean:', ean);
    
                var filteredList = await fetchData(ean);

                filteredList.forEach(item =>{


                    if (!catalog[item.data.productid]) {
                        catalog[item.data.productid] = {};

                    } 

                    if (!catalog[item.data.productid][item.code] && item.code) {
                        
                        catalog[item.data.productid][item.code] = {};
                        catalog[item.data.productid][item.code]['codes'] = [];

                    }

                    if (item.code){
                        var info = {
                        
                            "color": item.data.color != "" ? item.data.color : "",
                            "size": item.data.size != "" ? item.data.size : "",

                        }; 

                        catalog[item.data.productid][item.code]['info'] = info;
                        catalog[item.data.productid][item.code]['codes'].push(item.code);
                        
                    }

                    if(item.data.skuid){

                        catalog[item.data.productid][item.data.skuid]['codes'].push(item.code);

                    }

                })

                if (filteredList.length > 0){
                    

                    var info = getInfoForInfo(ean, filteredList[1]);
                    inventory[ean]['info'] = info;
                    
                } 
            
            } catch (error) {
                console.error('Error finding code:', error);
                throw error; 
            } 

            console.log('inv', inventory);
            console.log('catalogee', catalog);

        })
        
    }


    function sizesAndColors(productId) {
        var colors = [];
        var sizes = [];

        // Check if the product exists in the catalog
        if (catalog[productId]) {
            // Iterate over each SKU for the specified productid
            Object.keys(catalog[productId]).forEach(function(skuid) {

                var matchingCode = catalog[productId][skuid]['codes'].find(code => code in inventory);

                console.log('matchingcode', matchingCode);

                var color = catalog[productId][skuid]['info']['color'];
                var size = catalog[productId][skuid]['info']['size'];

                console.log('matchingcode', skuid);

                console.log(color);
                console.log(size);

                if (skuid || matchingCode){

                    if (skuid in inventory || matchingCode) {

                        if (inventory[matchingCode]){
        
                            inventory[matchingCode]['info']['size'] = size;
                            inventory[matchingCode]['info']['color'] = color;

                        }
                        if (inventory[skuid]){
        
                            inventory[skuid]['info']['size'] = size;
                            inventory[skuid]['info']['color'] = color;
                        }
                    
                        if (color) {
                            colors.push(color);
                        }

                        if (size) {
                            sizes.push(size);
                        }
                    }

                }


            });

            return {
                "colors": Array.from(new Set(colors)),
                "sizes": Array.from(new Set(sizes)),
            };
        }
    }
    
    function firstElement(){

        eans = eansToShow;

        min = Infinity;
        route = [];

        eansToShow.forEach(ean =>{

            coordsSum = inventory[ean['e']]['tags'][ean['c']]['info']['x'] + inventory[ean['e']]['tags'][ean['c']]['info']['z'];
            if (coordsSum < min){
                min = coordsSum;
                firstEan = ean['e'];
            }

        }) 
        
        eans = eans.filter(item => item['e'] !== firstEan);
        return {'e': firstEan,'c': firstEan['c']};

    }

    // SHOW MODAL

    function showModal() {
        // Create the modal elements
        const modal = document.createElement('div');
        modal.id = 'myModal';
        modal.style.display = 'flex';
        modal.style.position = 'fixed';
        modal.style.zIndex = '1';
        modal.style.left = '0';
        modal.style.top = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.overflow = 'auto';
        modal.style.backgroundColor = 'rgba(0,0,0,0.4)';
        modal.style.justifyContent = 'center';
        modal.style.alignItems = 'center';
    
        const modalContent = document.createElement('div');
        modalContent.style.backgroundColor = '#fefefe';
        modalContent.style.margin = 'auto';
        modalContent.style.padding = '20px';
        modalContent.style.border = '1px solid #888';
        modalContent.style.width = '80%';
        modalContent.style.maxWidth = '300px';
        modalContent.style.textAlign = 'center';
        modalContent.style.borderRadius = '10px'; // Rounded corners
    
        const message = document.createElement('p');
        message.textContent = 'Picking Completed';
    
        const closeBtn = document.createElement('button');
        closeBtn.textContent = 'OK';
        closeBtn.style.backgroundColor = '#333';
        closeBtn.style.color = 'white';
        closeBtn.style.border = 'none';
        closeBtn.style.padding = '10px 20px';
        closeBtn.style.textAlign = 'center';
        closeBtn.style.textDecoration = 'none';
        closeBtn.style.display = 'inline-block';
        closeBtn.style.fontSize = '16px';
        closeBtn.style.marginTop = '10px';
        closeBtn.style.cursor = 'pointer';
        closeBtn.style.borderRadius = '5px'; // Rounded button corners
    
        // Append elements
        modalContent.appendChild(message);
        modalContent.appendChild(closeBtn);
        modal.appendChild(modalContent);
        document.body.appendChild(modal);
    
        // Show the modal
        modal.style.display = 'flex';
    
        // Close the modal when the user clicks on the button
        closeBtn.onclick = function() {
            modal.style.display = 'none';
            document.body.removeChild(modal);
        };
    
        // Close the modal when the user clicks anywhere outside of the modal
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
                document.body.removeChild(modal);
            }
        };
    }


    function showMisplacedItems(codes) {
        let pending = codes.length;
    
        // Create a container for status
        const statusContainer = document.createElement("div");
        const statusSpan = document.createElement("span");
        statusSpan.classList.add("picking-status");
        statusSpan.innerHTML = `Pending: ${pending}`;
        statusContainer.appendChild(statusSpan);
        productList.appendChild(statusContainer);
    
        codes.forEach((code, i) => {
            let item = inventory[code['e']];
    
            if (i > 10) return;
    
            if (item) {
                const itemDiv = document.createElement("div");
                itemDiv.classList.add("product-item");
    
                const infoSpan = document.createElement("span");
                infoSpan.classList.add("product-info");
                infoSpan.innerHTML = `Product code: ${code['e']}`;
                infoSpan.style.fontWeight = "bold";
    
                const buttonsDiv = document.createElement("div");
                buttonsDiv.classList.add("button-container");
    
                const pickButton = document.createElement("button");
                pickButton.textContent = "Pick";
                pickButton.classList.add("pick-button");
    
                const hr = document.createElement('hr');
                hr.style.width = '100%';
                hr.style.border = 'none';
                hr.style.height = '1px';
    
                if (item.active) {
                    itemDiv.classList.add('enabled');
                    pickButton.disabled = false;
                } else {
                    itemDiv.classList.remove('enabled');
                    pickButton.disabled = true;
                }
    
                pickButton.onclick = function() {
                    pending--;
                    item.active = false;
                    itemDiv.classList.remove('enabled');
                    pickButton.disabled = true;
                    pickButton.textContent = "Picked";
                    statusSpan.innerHTML = `Pending: ${pending}`;
                    inventory[code['e']]['tags'][code['c']]['info']['misplaced'] = false;
    
                    if (i + 1 < codes.length) {
                        let nextCode = codes[i + 1]['e'];
                        if (inventory[nextCode]) {
                            inventory[nextCode].active = true;
                            let nextItemDiv = productList.querySelectorAll(".product-item")[i + 1];
                            if (nextItemDiv) {
                                nextItemDiv.classList.add('enabled');
                                let nextPickButton = nextItemDiv.querySelector(".pick-button");
                                nextPickButton.disabled = false;
                            }
                        }
                    } else {
                        showModal();
                    }
                };
    
                itemDiv.appendChild(infoSpan);
                itemDiv.appendChild(document.createElement("br")); 
                itemDiv.appendChild(buttonsDiv);
                itemDiv.appendChild(document.createElement("br")); 
                itemDiv.appendChild(pickButton);
    
                productList.appendChild(itemDiv);
            }
        });
    }
    
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    function showSelectedItems() { // EXPLICAR

        var inputArray = document.getElementById("tagsInput").value.replace(/\s/g, "").split(",");
        var codes = inputArray.filter((_, i) => i % 2 === 0);
        var quantities = inputArray.filter((_, i) => i % 2 !== 0).map(Number);

        var productList = document.getElementById("productList");


        productList.innerHTML = "";
        var notFoundCodes = [];

        //codes = makeRoute();
        console.log('codes',codes);

        codes.forEach(function(code, i) {
            var item = inventory[code]; 

            if (item) {

                var maxQuantity = item.info.quantity;
                var quantityPicked = 0;
                var notFound = 0;
                var requested = quantities[i];
                var pending = requested;

                var quantitySpan = document.createElement("span");
                quantitySpan.classList.add("product-quantity");
                quantitySpan.textContent = item.info.quantity;

                var quantityPickedSpan = document.createElement("span");
                quantityPickedSpan.classList.add("product-quantityPicked");
                quantityPickedSpan.textContent = quantityPicked;
                quantityPickedSpan.style.fontWeight = "normal"; 

                // Actualitzem valors 

                if (maxQuantity < requested){

                    notFound = requested - maxQuantity;
                    pending = maxQuantity;
                    var notFoundInfo = document.createElement("span");
                    notFoundInfo.classList.add("picking-status");
                    notFoundInfo.textContent = `Only ${maxQuantity} element/s with code ${code} present in the store`;

                }


                var editButton = document.createElement("button");
                editButton.classList.add("edit-button");

                // Create the pencil icon
                var pencilIcon = document.createElement("i");
                pencilIcon.classList.add("fa", "fa-edit");

                // Append the pencil icon to the edit button
                editButton.appendChild(pencilIcon);
    
                var itemDiv = document.createElement("div");
                itemDiv.classList.add("product-item");

                var titleSpan = document.createElement("span");
                titleSpan.classList.add("product-title");
                titleSpan.textContent = item.info.title;
                titleSpan.style.fontWeight = "bold"; 

                var infoSpan = document.createElement("span");
                infoSpan.classList.add("product-info");
                infoSpan.innerHTML = `Product ID: ${item.info.productid} - Size: ${item.info.size} - Color: ${item.info.color } - Quantity: `;

                var statusSpan = document.createElement("span");
                statusSpan.classList.add("picking-status");
                statusSpan.innerHTML = `Requested: ${requested} - Picked: ${quantityPicked} - Not Found: ${notFound} - Pending: ${pending}`;

                var buttonsDiv = document.createElement("div");
                buttonsDiv.classList.add("button-container");
                
                var pickButton = document.createElement("button");
                pickButton.textContent = "Pick";
                pickButton.classList.add("pick-button");

                var notfoundButton = document.createElement("button");
                notfoundButton.textContent = "Not Found";
                notfoundButton.classList.add("notfound-button");

                var hr = document.createElement('hr');

                hr.style.width = '100%';
                hr.style.border = 'none';
                hr.style.height = '1px';

                editButton.disabled = true;

                if (maxQuantity == 0){
                    pickButton.disabled = true;
                    notfoundButton.disabled = true;
                }


                if (item.active == true){
                    
                    itemDiv.classList.add('enabled');
                    editButton.classList.add('active');

                }else{

                    pickButton.disabled = true;
                    notfoundButton.disabled = true;
                }


                pickButton.onclick = function() {

                    item.info.quantity--;
                    quantitySpan.textContent = item.info.quantity;
                    picked = true;
                    quantityPicked++;
                    pending--;

                    if (item.active == true){
                    
                        itemDiv.classList.add('enabled');
        
                    }

                    if(item.info.quantity <= 0 | pending <= 0){

                        pickButton.disabled = true;
                        notfoundButton.disabled = true;

                    }

                    if(pending == 0){

                        item.active = false;
                        itemDiv.classList.remove('enabled');
                        editButton.disabled = false;
                        //no se
                        editButton.classList.remove('active');

                        if (i + 1 < codes.length) {
                            var nextCode = codes[i + 1];
                            if (inventory[nextCode]) {
                                inventory[nextCode].active = true;
                                var nextItemDiv = productList.children[i + 1];
                                if (nextItemDiv) {
                                    nextItemDiv.classList.add('enabled');
                                    var nextPickButton = nextItemDiv.querySelector(".pick-button");
                                    var nextNotFoundButton = nextItemDiv.querySelector(".notfound-button");
                                    var nextEditButton = nextItemDiv.querySelector(".edit-button");
                                    nextPickButton.disabled = false;
                                    nextNotFoundButton.disabled = false;
                                    //no se
                                    nextEditButton.classList.add('active');
                                }
                            }
                        }else{

                            showModal(); 
                        }
                        
                    }


                    titleSpan.textContent = item.info.title;
                    titleSpan.style.fontWeight = "bold"; 
                    //infoSpan.innerHTML = `Product ID: ${item.info.productid} - Size: ${item.info.size} - Color: ${item.info.color } - Quantity: `;
                    statusSpan.innerHTML = `Requested: ${requested} - Picked: ${quantityPicked} - Not Found: ${notFound} - Pending: ${pending}`;

                }; 

                console.log(item);

                notfoundButton.onclick = function() {

                    item.info.quantity--;
                    quantitySpan.textContent = item.info.quantity;
                    notFound++;
                    pending--;

                    if (item.active == true){
                    
                        itemDiv.classList.add('enabled');
        
                    }

                    if(item.info.quantity <= 0 | pending <= 0){

                        pickButton.disabled = true;
                        notfoundButton.disabled = true;

                    }

                    if(pending == 0){

                        item.active = false;
                        itemDiv.classList.remove('enabled');
                        editButton.disabled = false;
                        //no se
                        editButton.classList.remove('active');

                        if (i + 1 < codes.length) {
                            var nextCode = codes[i + 1];
                            if (inventory[nextCode]) {
                                inventory[nextCode].active = true;
                                var nextItemDiv = productList.children[i + 1];
                                if (nextItemDiv) {
                                    nextItemDiv.classList.add('enabled');
                                    var nextPickButton = nextItemDiv.querySelector(".pick-button");
                                    var nextNotFoundButton = nextItemDiv.querySelector(".notfound-button");
                                    var nextEditButton = nextItemDiv.querySelector(".edit-button");
                                    nextPickButton.disabled = false;
                                    nextNotFoundButton.disabled = false;
                                    //no se
                                    nextEditButton.classList.add('active');
                                }
                            }
                        }else{

                            showModal(); // REVISAR Y PONER BOTÓN NEGRO

                        }

                        if (inventory[codes[i + 1]]){
                            inventory[codes[i + 1]].active = true;
        
                        }
                        
                    }

                    titleSpan.textContent = item.info.title;
                    titleSpan.style.fontWeight = "bold"; 
                    //infoSpan.innerHTML = `Product ID: ${item.info.productid} - Size: ${item.info.size} - Color: ${item.info.color } - Quantity: `;
                    statusSpan.innerHTML = `Requested: ${requested} - Picked: ${quantityPicked} - Not Found: ${notFound} - Pending: ${pending}`;

                };

                editButton.onclick = function() {

                    item.info.quantity = maxQuantity;
                    quantityPicked = 0;
                    requested = quantities[i];
                    notFound = requested - maxQuantity;
                    pending = requested;

                    quantitySpan.textContent = item.info.quantity;

                    //infoSpan.innerHTML = `Product ID: ${item.info.productid} - Size: ${item.info.size} - Color: ${item.info.color } - Quantity: `;
                    statusSpan.innerHTML = `Requested: ${requested} - Picked: ${quantityPicked} - Not Found: ${notFound} - Pending: ${pending}`;

                    pickButton.disabled = false;
                    notfoundButton.disabled = false;

                }

                if (item.active == true){
                    infoSpan.classList.add('enabled');
                }

                itemDiv.appendChild(titleSpan);
                itemDiv.appendChild(hr);   
                itemDiv.appendChild(document.createElement("br"));
                itemDiv.appendChild(infoSpan);
                itemDiv.appendChild(quantitySpan);
                itemDiv.appendChild(document.createElement("br"));
                itemDiv.appendChild(document.createElement("br")); 
                itemDiv.appendChild(statusSpan);

                if (notFoundInfo){

                    itemDiv.appendChild(document.createElement("br")); 
                    itemDiv.appendChild(notFoundInfo);
                }

                itemDiv.appendChild(buttonsDiv);
                itemDiv.appendChild(document.createElement("br")); 
                itemDiv.appendChild(pickButton);
                itemDiv.appendChild(notfoundButton);
                itemDiv.appendChild(editButton);

                productList.appendChild(itemDiv);

            } else {
                notFoundCodes.push(code); 
            }
        });


        if (notFoundCodes.length > 0){
            var notFoundDiv = document.createElement("div");
            notFoundDiv.classList.add("product-item");
            notFoundDiv.textContent = "Item/s with code/s " + notFoundCodes.join(", ") + " not found.";
            notFoundDiv.classList.add("not-found-message");
            productList.appendChild(notFoundDiv);
        }
    }



    function onShowcaseConnect() {
        MPSDK.Model.getData().then((modelData) => {
            console.log('Model sid:' + modelData['sid']);
        }).catch((err) => {
            console.error(err);
        });

        // load inventory data
        tfg.inventory.getInventory().then((res) => {
            console.log("inventory:", res);
            inventory = res;

        })
    }


    function getHTMLForItem(item, clusterInfo) {
        var html = `<div style="background-color: #222222; padding: 10px; border-radius: 5px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); text-align: center;">`;

        html += `<h3 style="color: #fff; font-size: 18px; margin: 0; padding-bottom: 5px; border-bottom: 1px solid #444;">${item['info']['title']}</h3>`;

        html += `<div style="padding-top: 10px;">`; 

        html += `<img src="${item['info']['image']}" style="display: block; margin: 0 auto; width: 225px; height: auto; border-radius: 5px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); padding-top: 10px;" />`; // Added padding-top for space

        html += `</div>`;

        html += `<div style="padding-top: 5px;">`;
        
        if (showCoords) {
            html += `<p style="color: #ccc; font-size: 14px; margin: 5px 0 0;">X: ${clusterInfo['x']} Z: ${clusterInfo['z']}</p>`;
        }

        html += `</div>`;

        html += `</div>`;

        return html;
    }

    
    
    function generateHTMLContentForInventoryItem(item, cluster, code) {

        // Define the pick condition

        // Check if the 'sid' exists and if the pick condition is met

        // BORRON
        if (!item['tags'][cluster]['sid']) return;

        // Register the sandbox and attach the item tag
        MPSDK.Tag.registerSandbox(getHTMLForItem(item, item['tags'][cluster]['info']), {
            size: {
                w: 400,
                h: 400,
            }
        })
        .then(function(sandboxIdArray) {
            const sandboxId = sandboxIdArray[0];
            MPSDK.Tag.attach(item['tags'][cluster]['sid'], sandboxId);
        })
        .catch(function(error) {
            console.error(error);
        });
    }


    function eanAndClusterIsInArray(array, theEan) {
        for(var ean of array) {
            if(ean['e'] == theEan['e'] && ean['c'] == theEan['c']) return true;
        }
        return false;
    }

    function distanceBetweenItems (item1, item2) {
        // console.log(item1['x'], item1['z']);
        var v1 = new Vector(item1['x'], item1['z']);
        var v2 = new Vector(item2['x'], item2['z']);
        // console.log(v1, v2);
        return v1.distanceFrom(v2);
    }

    function selectButtonFromButtonBar (buttonID) {
        var buttons = document.getElementsByClassName("btn-selected");
        for (let btn of buttons) {
            btn.classList.remove("btn-selected");
        }

        var theButton = document.getElementById(buttonID);
        if(theButton) {
            theButton.classList.add("btn-selected");
        }
    }

    return {
        connectSdk: function () {
            const sdkKey = 'tyf252y2d6k9sxh45e3hzr1xb'
            const iframe = document.getElementById('showcase-iframe');

            window.MP_SDK.connect(iframe, sdkKey, '').then((result) => {
                MPSDK = result;
                onShowcaseConnect();
                MPSDK.Mode.current.subscribe(function (mode) {
                    // the view mode has changed
                    console.log('Current view mode is ', mode);
                    viewMode = mode;
                });
            }).catch((err) => {
                console.error(err);
            });
        },
        
        showCurrentItems: function (options,misplaced) {
            eansToShow.forEach(ean => {


                var item = inventory[ean['e']];
                var cluster = item['tags'][ean['c']];
                var sizeColor = sizesAndColors(item['info']['productid']);
                if (cluster['sid'] || options && options['only-misplaced'] && !cluster['info']['misplaced']) return;
                MPSDK.Tag.add({
                    label: `Code: ${ean['e']}`,
                    anchorPosition: { x: parseFloat(cluster['info']['x']), y: parseFloat(cluster['info']['y']), z: parseFloat(cluster['info']['z']) },
                    stemVector: { x: 0, y: 0, z: 0 },
                    color: cluster['info']['misplaced'] ? RED_TAG : BLUE_TAG,
                }).then(sid => {


                    cluster['sid'] = sid[0];

                    generateHTMLContentForInventoryItem(item, ean['c'], ean['e']);
                
                    var observer = new MutationObserver(mutationsList => {
                        mutationsList.forEach(mutation => {
                            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                                var tagLabel = document.querySelector('.mps-tag-label');
                                if (tagLabel) {
                                    tagLabel.style.textAlign = 'right';
                                    observer.disconnect();
                                }
                            }
                        });
                    });
                
                    observer.observe(document.body, { childList: true, subtree: true });
                    if (misplaced) {
                        showMisplacedItems(eansToShow);
                    } else{
                        showSelectedItems();
                    }

                    
                    
                })
                
            })
        },

        addAllClustersForEan: function (ean) {
            Object.keys(inventory[ean]['tags']).forEach(clu => {
                if (inventory[ean]['tags'][clu]['info']['misplaced'] == false) {
                    eansToShow.push({'e': ean, 'c': clu});

                    eansToShow.forEach(function(code, i){

                        if (inventory[code['e']]){
                            if (i === 0){
                                inventory[[code['e']]]['active'] = true;
                            }else{
                                inventory[code['e']]['active'] = false;
                            }

                        }
                        
                    });

                }
            })
        },

        showAllItems: function () {
            this.removeCurrentItems();
            var eans = Object.keys(inventory);
            var i = 0;
            for(var ean of eans) {
                this.addAllClustersForEan(ean);
                i++;
            }
            
            this.showCurrentItems();
        },    
        
        clearSelected: function () {
            var productList = document.getElementById("productList");
            productList.innerHTML = ""; 
            pickedItems = []; 
        },

        showMisplaced: function () {
            this.removeCurrentItems();
            this.clearSelected();
            var i = 0;
            Object.keys(inventory).forEach(ean => {
                i++;
                var item = inventory[ean];
                Object.keys(item['tags']).forEach(c => {
                    var cluster = item['tags'][c];
                    if (!eanAndClusterIsInArray(eansToShow, {'e': ean, 'c': c}) && cluster['info']['misplaced'] == true) {
                        eansToShow.push({'e': ean, 'c': c});
                    }
                })
            })

            eansToShow.forEach(function(code, i){

                if (inventory[code['e']]){
                    if (i === 0){
                        inventory[[code['e']]]['active'] = true;
                    }else{
                        inventory[code['e']]['active'] = false;
                    }

                }
                
            });
            console.log('eans',eansToShow);
            this.showCurrentItems({'only-misplaced': true}, true);
        },

        removeProductByEAN: async function (eanToRemove) {
            eans = eansToShow.filter(item => item['e'] != eanToRemove);
            this.removeCurrentItems();
            if(eans) {
                eansToShow = eans;
                this.showCurrentItems();
                await this.getBestPathForCurrentItems();
            } else {
                selectedItemIndex = null;
            }
        },
        
        removeCurrentItems: function () {
            this.selectItem(null);
            eansToShow.forEach(ean => {
                var item = inventory[ean['e']];
                var cluster = item['tags'][ean['c']];
                if (!cluster['sid']) return;
                MPSDK.Tag.remove(cluster['sid']);
                cluster['sid'] = null;
            })
            eansToShow = [];
        },

        setCurrentItems: function (codes) {
            if (!codes) return;
            this.removeCurrentItems();

            codes.forEach(ean => {
                const item = inventory[ean];
                if (item != undefined) {
                    this.addAllClustersForEan(ean);
                }
            })
            this.showCurrentItems();
        },

        setCurrentItemsButton: async function () {
            selectButtonFromButtonBar("buttonFind");
            var inputArray = document.getElementById("tagsInput").value.replace(/\s/g, "").split(",");
            var codes = inputArray.filter((_, i) => i % 2 === 0);

            updateInventory(codes);
            console.log('inventory updated', inventory[codes[0]]);
            this.clearProductsFound();
            this.setCurrentItems(codes);
            await this.getBestPathForCurrentItems();
        },

        showAllItemsButton: async function () {
            selectButtonFromButtonBar("buttonShowAll");
            this.clearProductsFound();
            this.showAllItems();
        },

        showMisplacedButton: async function () {
            selectButtonFromButtonBar("buttonMisplaced");
            this.clearProductsFound();
            this.showMisplaced();
            await this.getBestPathForCurrentItems();
        },

        removeCurrentItemsButton: function () {
            selectButtonFromButtonBar("buttonHideAll");
            this.clearProductsFound();
            this.removeCurrentItems();
        },

        clearSelectedButton: function() {
            this.clearSelected();
        },


        selectItem: function (id) { // CANVIAR + EXPLICAR
            
            // Object.keys(item['tags']).forEach(c => {
            //     var cluster = item['tags'][c];
            //     if (!cluster['sid']) return;
            //     MPSDK.Mattertag.remove(cluster['sid']);
            //     cluster['sid'] = null;
            // })
            
            if(selectedItemIndex!=null) { 
                var item = inventory[eansToShow[selectedItemIndex]['e']]['tags'][eansToShow[selectedItemIndex]['c']]; //previous item
                var color = item['info']['misplaced'] ? RED_TAG : BLUE_TAG;
                MPSDK.Tag.editColor(item['sid'], color);
            }

            selectedItemIndex = id;
            // console.log("id:",selectedItemIndex);
            // console.log("eans:",eansToShow);
            // console.log("items:",inventory);
            if(selectedItemIndex!=null) { 
                item = inventory[eansToShow[selectedItemIndex]['e']]['tags'][eansToShow[selectedItemIndex]['c']]; //current item
                var sel_color = item['info']['misplaced'] ? RED_TAG_SEL : BLUE_TAG_SEL;
                MPSDK.Tag.editColor(item['sid'], sel_color);
                if(viewMode == "mode.inside") {
                    MPSDK.Mattertag.navigateToTag(item['sid'], MPSDK.Mattertag.Transition.FADEOUT);
                }
            }
        },

        selectNextItem: function () { // CANVIAR + EXPLICAR
            var n = eansToShow.length;
            if(n > 0) {
                var next = selectedItemIndex==null ? 0 : (selectedItemIndex+1)%n;
                this.selectItem(next);
            }
        },

        selectPreviousItem: function () { // CANVIAR + EXPLICAR
            var n = eansToShow.length;
            if(n > 0) {
                var prev = selectedItemIndex==null ? 0 : (((selectedItemIndex-1)%n)+n)%n;
                this.selectItem(prev);
            }
        },

        getBestPathForCurrentItems: async function () {
            var init = new Date(); //remove
            if(eansToShow.length < 1) return;

            if(/*document.getElementById("antsCheck").checked*/ false) {
                this.selectItem(null);
                //currentItemsToShow = tfg.ants.getBestPathForItemsList(currentItemsToShow);
            } else {
                var cameraPose = await MPSDK.Camera.getPose();
                var myPosition = cameraPose.position;
                var visitedCodes = [];
    
                function findRemainingClosestCodeToPosition (pos) {
                    var minDistance = Infinity;
                    var nearestItem = null;
                    eansToShow.forEach(ean => {
                        const item = inventory[ean['e']]['tags'][ean['c']];
                        if (eanAndClusterIsInArray(visitedCodes, ean)) return;
                        var d = distanceBetweenItems(pos, item['info']);
                        if (d < minDistance) {
                            minDistance = d;
                            nearestItem = ean;
                        }
                    })
                    visitedCodes.push(nearestItem);
                    return inventory[nearestItem['e']]['tags'][nearestItem['c']];
                }
    
                var currentItem = findRemainingClosestCodeToPosition(myPosition);
                while (visitedCodes.length < eansToShow.length) {
                    currentItem = findRemainingClosestCodeToPosition(currentItem['info']);
                }

                console.log(eansToShow);
                this.selectItem(null);
                eansToShow = visitedCodes;
                // currentItemsToShow = visitedCodes;
            }
            
            
            var end = new Date(); //remove
            console.log((end.getTime() - init.getTime()));
            console.log(eansToShow);
            this.selectItem(0);
            // return visitedCodes;
        },
        addEanToProductsFound: function (ean) {
            var item = inventory[ean];
            if(!item) return;
    
            var productsContainer = document.getElementById("productList");
            productsContainer.innerHTML += 
            `<div class="product">
                <div class="barcode">
                ${ean}
                </div>
                <div class="description">
                ${item['info']['title']}
                </div>
            </div>`;
        },
        clearProductsFound: function () {
            pickedItems = [];
            var productsContainer = document.getElementById("productList");
            productsContainer.innerHTML = "";
        }
    };

})();

window['tfg']=tfg;
tfg['app']=tfg.app;