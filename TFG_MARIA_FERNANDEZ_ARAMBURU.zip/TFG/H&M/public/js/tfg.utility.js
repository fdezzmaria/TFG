var tfg = tfg || {};

tfg.utility = tfg.utility || (function () {


    // Get file object from path. Returns file object
    async function getFile(path, name) {

        let response = await fetch(path);
        let data = await response.blob();
        let file = new File([data], name);
        return file
    }

    // Read file as raw text. Returns Promise that resolves in the text
    function readFileAsText(inputFile) {
        const reader = new FileReader();

        return new Promise((resolve, reject) => {
            reader.onerror = () => {
                reader.abort();
                reject(new DOMException("Problem parsing input file."));
            };

            reader.onload = () => {
                resolve(reader.result);
            };
            reader.readAsText(inputFile);
        });
    }

    // Transforms CSV string to json array
    function csvToArray(str, headers, delimiter = ",") {

        str = str.replaceAll("\r", "")
        let rows;

        if (!headers) {
            headers = str.slice(0, str.indexOf("\n")).split(delimiter);
            rows = str.slice(str.indexOf("\n") + 1).split("\n");
        } else {
            rows = str.split("\n");
        }
        let arr = rows.map(function (row) {
         	let values;
            if (delimiter == ",") {
               //split by comma but not when inside quotes
            //    values = row.match(/(".*?"|[^",]+)(?=\s*,|\s*$)/g);
               values = row.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
            } else {
               values = row.split(delimiter);
			}
			const el = headers.reduce(function (object, header, index) {
				if (values.length > index) {
					object[header] = values[index];
				}
				return object;
			}, {});
			return el;
            
        });

        return arr;
    }

    return {
        // Use this to read csv files, it uses all functions above
        readAndParseCSVFile: async function (path, name, header) {
            const dataFile = await getFile(path, name);
            var parsedCSV;
            try {
                var text = await readFileAsText(dataFile);
                parsedCSV = csvToArray(text, header);
            } catch (e) {
                console.warn(e.message);
            }
            return parsedCSV;
        },

        /*	This work is licensed under Creative Commons GNU LGPL License.

            License: http://creativecommons.org/licenses/LGPL/2.1/
            Version: 0.9
            Author:  Stefan Goessner/2006
            Web:     http://goessner.net/ 
        */
        parseXml: function(xml) {
            var dom = null;
            if (window.DOMParser) {
                try { 
                    dom = (new DOMParser()).parseFromString(xml, "text/xml"); 
                } 
                catch (e) { dom = null; }
            }
            else if (window.ActiveXObject) {
                try {
                    dom = new ActiveXObject('Microsoft.XMLDOM');
                    dom.async = false;
                    if (!dom.loadXML(xml)) // parse error ..
            
                        window.alert(dom.parseError.reason + dom.parseError.srcText);
                } 
                catch (e) { dom = null; }
            }
            else
                alert("cannot parse xml string!");
            return dom;
        },
        xml2json: function (xml, tab) {
            var X = {
                toObj: function(xml) {
                   var o = {};
                   if (xml.nodeType==1) {   // element node ..
                      if (xml.attributes.length)   // element with attributes  ..
                         for (var i=0; i<xml.attributes.length; i++)
                            o["@"+xml.attributes[i].nodeName] = (xml.attributes[i].nodeValue||"").toString();
                      if (xml.firstChild) { // element has child nodes ..
                         var textChild=0, cdataChild=0, hasElementChild=false;
                         for (var n=xml.firstChild; n; n=n.nextSibling) {
                            if (n.nodeType==1) hasElementChild = true;
                            else if (n.nodeType==3 && n.nodeValue.match(/[^ \f\n\r\t\v]/)) textChild++; // non-whitespace text
                            else if (n.nodeType==4) cdataChild++; // cdata section node
                         }
                         if (hasElementChild) {
                            if (textChild < 2 && cdataChild < 2) { // structured element with evtl. a single text or/and cdata node ..
                               X.removeWhite(xml);
                               for (var n=xml.firstChild; n; n=n.nextSibling) {
                                  if (n.nodeType == 3)  // text node
                                     o["#text"] = X.escape(n.nodeValue);
                                  else if (n.nodeType == 4)  // cdata node
                                     o["#cdata"] = X.escape(n.nodeValue);
                                  else if (o[n.nodeName]) {  // multiple occurence of element ..
                                     if (o[n.nodeName] instanceof Array)
                                        o[n.nodeName][o[n.nodeName].length] = X.toObj(n);
                                     else
                                        o[n.nodeName] = [o[n.nodeName], X.toObj(n)];
                                  }
                                  else  // first occurence of element..
                                     o[n.nodeName] = X.toObj(n);
                               }
                            }
                            else { // mixed content
                               if (!xml.attributes.length)
                                  o = X.escape(X.innerXml(xml));
                               else
                                  o["#text"] = X.escape(X.innerXml(xml));
                            }
                         }
                         else if (textChild) { // pure text
                            if (!xml.attributes.length)
                               o = X.escape(X.innerXml(xml));
                            else
                               o["#text"] = X.escape(X.innerXml(xml));
                         }
                         else if (cdataChild) { // cdata
                            if (cdataChild > 1)
                               o = X.escape(X.innerXml(xml));
                            else
                               for (var n=xml.firstChild; n; n=n.nextSibling)
                                  o["#cdata"] = X.escape(n.nodeValue);
                         }
                      }
                      if (!xml.attributes.length && !xml.firstChild) o = null;
                   }
                   else if (xml.nodeType==9) { // document.node
                      o = X.toObj(xml.documentElement);
                   }
                   else
                      alert("unhandled node type: " + xml.nodeType);
                   return o;
                },
                toJson: function(o, name, ind) {
                   var json = name ? ("\""+name+"\"") : "";
                   if (o instanceof Array) {
                      for (var i=0,n=o.length; i<n; i++)
                         o[i] = X.toJson(o[i], "", ind+"\t");
                      json += (name?":[":"[") + (o.length > 1 ? ("\n"+ind+"\t"+o.join(",\n"+ind+"\t")+"\n"+ind) : o.join("")) + "]";
                   }
                   else if (o == null)
                      json += (name&&":") + "null";
                   else if (typeof(o) == "object") {
                      var arr = [];
                      for (var m in o)
                         arr[arr.length] = X.toJson(o[m], m, ind+"\t");
                      json += (name?":{":"{") + (arr.length > 1 ? ("\n"+ind+"\t"+arr.join(",\n"+ind+"\t")+"\n"+ind) : arr.join("")) + "}";
                   }
                   else if (typeof(o) == "string")
                      json += (name&&":") + "\"" + o.toString() + "\"";
                   else
                      json += (name&&":") + o.toString();
                   return json;
                },
                innerXml: function(node) {
                   var s = ""
                   if ("innerHTML" in node)
                      s = node.innerHTML;
                   else {
                      var asXml = function(n) {
                         var s = "";
                         if (n.nodeType == 1) {
                            s += "<" + n.nodeName;
                            for (var i=0; i<n.attributes.length;i++)
                               s += " " + n.attributes[i].nodeName + "=\"" + (n.attributes[i].nodeValue||"").toString() + "\"";
                            if (n.firstChild) {
                               s += ">";
                               for (var c=n.firstChild; c; c=c.nextSibling)
                                  s += asXml(c);
                               s += "</"+n.nodeName+">";
                            }
                            else
                               s += "/>";
                         }
                         else if (n.nodeType == 3)
                            s += n.nodeValue;
                         else if (n.nodeType == 4)
                            s += "<![CDATA[" + n.nodeValue + "]]>";
                         return s;
                      };
                      for (var c=node.firstChild; c; c=c.nextSibling)
                         s += asXml(c);
                   }
                   return s;
                },
                escape: function(txt) {
                   return txt.replace(/[\\]/g, "\\\\")
                             .replace(/[\"]/g, '\\"')
                             .replace(/[\n]/g, '\\n')
                             .replace(/[\r]/g, '\\r');
                },
                removeWhite: function(e) {
                   e.normalize();
                   for (var n = e.firstChild; n; ) {
                      if (n.nodeType == 3) {  // text node
                         if (!n.nodeValue.match(/[^ \f\n\r\t\v]/)) { // pure whitespace text node
                            var nxt = n.nextSibling;
                            e.removeChild(n);
                            n = nxt;
                         }
                         else
                            n = n.nextSibling;
                      }
                      else if (n.nodeType == 1) {  // element node
                         X.removeWhite(n);
                         n = n.nextSibling;
                      }
                      else                      // any other node
                         n = n.nextSibling;
                   }
                   return e;
                }
             };
             if (xml.nodeType == 9) // document node
                xml = xml.documentElement;
             var json = X.toJson(X.toObj(X.removeWhite(xml)), xml.nodeName, "\t");
             return "{\n" + tab + (tab ? json.replace(/\t/g, tab) : json.replace(/\t|\n/g, "")) + "\n}";
        },
        httpGet: function(theUrl) {
            let xmlHttpReq = new XMLHttpRequest();
            xmlHttpReq.open("GET", theUrl, false); 
            xmlHttpReq.send(null);
            return xmlHttpReq.responseText;
        }
    }
})();


function saveCsvLocally(csvData, filename) {
   const blob = new Blob([csvData], { type: 'text/csv' });
   const url = URL.createObjectURL(blob);
   const a = document.createElement('a');
   a.href = url;
   a.download = filename || 'data.csv';
   a.click();
   URL.revokeObjectURL(url);
}


function jsonToCsvAndSave(items, filename) {
   const header = Object.keys(items[0].data);
   const headerString = header.join(',');
   const replacer = (key, value) => value ?? '';
   const rowItems = items.map((item) =>
       header.map((fieldName) => JSON.stringify(item.data[fieldName], replacer)).join(',')
   );
   const csv = [headerString, ...rowItems].join('\r\n');

   // Save CSV locally
   saveCsvLocally(csv, filename);

   return csv;
}

