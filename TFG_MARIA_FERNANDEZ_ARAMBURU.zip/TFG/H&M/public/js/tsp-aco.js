class Graph {
    constructor() {
        this._cities = [];
        this._edges = {};
    }
    getEdges() { return this._edges; }
    getEdgeCount() { return Object.keys(this._edges).length; }
    getCity(cityIndex) {
        return this._cities[cityIndex];
    }
    getCities() {
        return this._cities;
    }
    size() {
        return this._cities.length;
    }
    addCity(id, x, y) {
        this._cities.push(new City(id, x, y));
    }
    _addEdge(cityA, cityB) {
        this._edges[cityA.toString() + '-' + cityB.toString()] = new Edge(cityA, cityB);
    }
    getEdge(cityA, cityB) {
        if (this._edges[cityA.toString() + '-' + cityB.toString()] != undefined) {
            return this._edges[cityA.toString() + '-' + cityB.toString()];
        }
        if (this._edges[cityB.toString() + '-' + cityA.toString()] != undefined) {
            return this._edges[cityB.toString() + '-' + cityA.toString()];
        }
    }
    createEdges() {
        this._edges = {};

        for (var cityIndex = 0; cityIndex < this._cities.length; cityIndex++) {
            for (var connectionIndex = cityIndex; connectionIndex < this._cities.length; connectionIndex++) {
                this._addEdge(this._cities[cityIndex], this._cities[connectionIndex]);
            }
        }
    }
    resetPheromone() {
        for (var edgeIndex in this._edges) {
            this._edges[edgeIndex].resetPheromone();
        }
    }
    clear() {
        this._cities = [];
        this._edges = {};
    }
}

class City {
    constructor(id, x, y) {
        this._id = id;
        this._x = x;
        this._y = y;
    }
    getId() { return this._id; }
    getX() { return this._x; }
    getY() { return this._y; }
    toString() {
        return this._x + ',' + this._y;
    }
    isEqual(city) {
        if (this._id == city._id && this._x == city._x && this._y == city._y) {
            return true;
        }
        return false;
    }
}

class Edge {
    constructor(cityA, cityB) {
        this._cityA = cityA;
        this._cityB = cityB;
        this._initPheromone = 1;
        this._pheromone = this._initPheromone;

        // Calculate edge distance
        var deltaXSq = Math.pow((cityA.getX() - cityB.getX()), 2);
        var deltaYSq = Math.pow((cityA.getY() - cityB.getY()), 2);
        this._distance = Math.sqrt(deltaXSq + deltaYSq);
    }
    pointA() {
        return { 'x': this._cityA.getX(), 'y': this._cityA.getY() };
    }
    pointB() {
        return { 'x': this._cityB.getX(), 'y': this._cityB.getY() };
    }
    getPheromone() { return this._pheromone; }
    getDistance() { return this._distance; }
    contains(city) {
        if (this._cityA.getX() == city.getX()) {
            return true;
        }
        if (this._cityB.getX() == city.getX()) {
            return true;
        }
        return false;
    }
    setInitialPheromone(pheromone) {
        this._initPheromone = pheromone;
    }
    setPheromone(pheromone) {
        this._pheromone = pheromone;
    }
    resetPheromone() {
        this._pheromone = this._initPheromone;
    }
}

class AntColony {
    constructor(params) {
        this._graph = new Graph();
        this._colony = [];

        // Set default params
        this._colonySize = 20;
        this._alpha = 1;
        this._beta = 3;
        this._rho = 0.1;
        this._q = 1;
        this._initPheromone = this._q;
        this._type = 'acs';
        this._elitistWeight = 0;
        this._maxIterations = 250;
        this._minScalingFactor = 0.001;

        this.setParams(params);

        this._iteration = 0;
        this._minPheromone = null;
        this._maxPheromone = null;

        this._iterationBest = null;
        this._globalBest = null;

        this._createAnts();
    }
    getGraph() { return this._graph; }
    getAnts() { return this._colony; }
    size() { return this._colony.length; }
    currentIteration() { return this._iteration; }
    maxIterations() { return this._maxIterations; }
    _createAnts() {
        this._colony = [];
        for (var antIndex = 0; antIndex < this._colonySize; antIndex++) {
            this._colony.push(new Ant(this._graph, {
                'alpha': this._alpha,
                'beta': this._beta,
                'q': this._q,
            }));
        }
    }
    setParams(params) {
        if (params != undefined) {
            if (params.colonySize != undefined) {
                this._colonySize = params.colonySize;
            }
            if (params.alpha != undefined) {
                this._alpha = params.alpha;
            }
            if (params.beta != undefined) {
                this._beta = params.beta;
            }
            if (params.rho != undefined) {
                this._rho = params.rho;
            }
            if (params.iterations != undefined) {
                this._maxIterations = params.iterations;
            }
            if (params.q != undefined) {
                this._q = params.q;
            }
            if (params.initPheromone != undefined) {
                this._initPheromone = params.initPheromone;
            }
            if (params.type != undefined) {
                if (params.type == 'elitist') {
                    if (params.elitistWeight != undefined) {
                        this._elitistWeight = params.elitistWeight;
                        this._type = 'elitist';
                    }
                } else if (params.type == 'maxmin') {
                    this._type = 'maxmin';
                } else {
                    this._type = 'acs';
                }
            }
            if (params.minScalingFactor != undefined) {
                this._minScalingFactor = params.minScalingFactor;
            }
        }
    }
    reset() {
        this._iteration = 0;
        this._globalBest = null;
        this.resetAnts();
        this.setInitialPheromone(this._initPheromone);
        this._graph.resetPheromone();
    }
    setInitialPheromone() {
        var edges = this._graph.getEdges();
        for (var edgeIndex in edges) {
            edges[edgeIndex].setInitialPheromone(this._initPheromone);
        }
    }
    resetAnts() {
        this._createAnts();
        this._iterationBest = null;
    }
    ready() {
        if (this._graph.size() <= 1) {
            return false;
        }
        return true;
    }
    run() {
        if (!this.ready()) {
            return;
        }

        this._iteration = 0;
        while (this._iteration < this._maxIterations) {
            // console.log(this._iteration);
            this.step();
        }
    }
    step() {
        if (!this.ready() || this._iteration >= this._maxIterations) {
            return;
        }

        this.resetAnts();

        for (var antIndex in this._colony) {
            this._colony[antIndex].run();
        }

        this.getGlobalBest();
        this.updatePheromone();

        this._iteration++;
    }
    updatePheromone() {
        var edges = this._graph.getEdges();
        for (var edgeIndex in edges) {
            var pheromone = edges[edgeIndex].getPheromone();
            edges[edgeIndex].setPheromone(pheromone * (1 - this._rho));
        }

        if (this._type == 'maxmin') {
            if ((this._iteration / this._maxIterations) > 0.75) {
                var best = this.getGlobalBest();
            } else {
                var best = this.getIterationBest();
            }

            // Set maxmin
            this._maxPheromone = this._q / best.getTour().distance();
            this._minPheromone = this._maxPheromone * this._minScalingFactor;

            best.addPheromone();
        } else {
            for (var antIndex in this._colony) {
                this._colony[antIndex].addPheromone();
            }
        }

        if (this._type == 'elitist') {
            this.getGlobalBest().addPheromone(this._elitistWeight);
        }

        if (this._type == 'maxmin') {
            for (var edgeIndex in edges) {
                var pheromone = edges[edgeIndex].getPheromone();
                if (pheromone > this._maxPheromone) {
                    edges[edgeIndex].setPheromone(this._maxPheromone);
                } else if (pheromone < this._minPheromone) {
                    edges[edgeIndex].setPheromone(this._minPheromone);
                }
            }
        }
    }
    getIterationBest() {
        if (this._colony[0].getTour() == null) {
            return null;
        }

        if (this._iterationBest == null) {
            var best = this._colony[0];

            for (var antIndex in this._colony) {
                if (best.getTour().distance() >= this._colony[antIndex].getTour().distance()) {
                    this._iterationBest = this._colony[antIndex];
                }
            }
        }

        return this._iterationBest;
    }
    getGlobalBest() {
        var bestAnt = this.getIterationBest();
        if (bestAnt == null && this._globalBest == null) {
            return null;
        }

        if (bestAnt != null) {
            if (this._globalBest == null || this._globalBest.getTour().distance() >= bestAnt.getTour().distance()) {
                this._globalBest = bestAnt;
            }
        }

        return this._globalBest;
    }
}

class Ant {
    constructor(graph, params) {
        this._graph = graph;

        this._alpha = params.alpha;
        this._beta = params.beta;
        this._q = params.q;
        this._tour = null;
    }
    reset() {
        this._tour = null;
    }
    init() {
        this._tour = new Tour(this._graph);
        var randCityIndex = Math.floor(Math.random() * this._graph.size());
        this._currentCity = this._graph.getCity(randCityIndex);
        this._tour.addCity(this._currentCity);
    }
    getTour() {
        return this._tour;
    }
    makeNextMove() {
        if (this._tour == null) {
            this.init();
        }

        var rouletteWheel = 0.0;
        var cities = this._graph.getCities();

        var cityProbabilities = [];
        for (var cityIndex in cities) {
            if (!this._tour.contains(cities[cityIndex])) {
                var edge = this._graph.getEdge(this._currentCity, cities[cityIndex]);
                if (this._alpha == 1) {
                    var finalPheromoneWeight = edge.getPheromone();
                } else {
                    var finalPheromoneWeight = Math.pow(edge.getPheromone(), this._alpha);
                }
                cityProbabilities[cityIndex] = finalPheromoneWeight * Math.pow(1.0 / edge.getDistance(), this._beta);
                rouletteWheel += cityProbabilities[cityIndex];
            }
        }

        var wheelTarget = rouletteWheel * Math.random();

        var wheelPosition = 0.0;
        for (var cityIndex in cities) {
            if (!this._tour.contains(cities[cityIndex])) {
                wheelPosition += cityProbabilities[cityIndex];
                if (wheelPosition >= wheelTarget) {
                    this._currentCity = cities[cityIndex];
                    this._tour.addCity(cities[cityIndex]);
                    return;
                }
            }
        }
    }
    tourFound() {
        if (this._tour == null) {
            return false;
        }
        return (this._tour.size() >= this._graph.size());
    }
    run(callback) {
        this.reset();
        while (!this.tourFound()) {
            this.makeNextMove();
        }
    }
    addPheromone(weight) {
        if (weight == undefined) {
            weight = 1;
        }

        var extraPheromone = (this._q * weight) / this._tour.distance();
        for (var tourIndex = 0; tourIndex < this._tour.size(); tourIndex++) {
            if (tourIndex >= this._tour.size() - 1) {
                var fromCity = this._tour.get(tourIndex);
                var toCity = this._tour.get(0);
                var edge = this._graph.getEdge(fromCity, toCity);
                var pheromone = edge.getPheromone();
                edge.setPheromone(pheromone + extraPheromone);
            } else {
                var fromCity = this._tour.get(tourIndex);
                var toCity = this._tour.get(tourIndex + 1);
                var edge = this._graph.getEdge(fromCity, toCity);
                var pheromone = edge.getPheromone();
                edge.setPheromone(pheromone + extraPheromone);
            }
        }
    }
}

class Tour {
    constructor(graph) {
        this._graph = graph;
        this._tour = [];
        this._distance = null;
    }
    size() { return this._tour.length; }
    contains(city) {
        for (var tourIndex in this._tour) {
            if (city.isEqual(this._tour[tourIndex])) {
                return true;
            }
        }

        return false;
    }
    addCity(city) {
        this._distance = null;
        this._tour.push(city);
    }
    get(tourIndex) {
        return this._tour[tourIndex];
    }
    getTour() {
        return this._tour;
    }
    distance() {
        if (this._distance == null) {
            var distance = 0.0;

            for (var tourIndex = 0; tourIndex < this._tour.length; tourIndex++) {
                if (tourIndex >= this._tour.length - 1) {
                    var edge = this._graph.getEdge(this._tour[tourIndex], this._tour[0]);
                    distance += edge.getDistance();
                } else {
                    var edge = this._graph.getEdge(this._tour[tourIndex], this._tour[tourIndex + 1]);
                    distance += edge.getDistance();
                }
            }

            this._distance = distance;
        }

        return this._distance;
    }
}