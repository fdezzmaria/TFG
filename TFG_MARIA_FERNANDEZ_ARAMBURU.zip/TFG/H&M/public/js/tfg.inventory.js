var tfg = tfg || {};

tfg.inventory = tfg.inventory || (function () {
    var inventory = null;
    var catalog = null;

    var filterByCatalog = true;
    var filterOutside = true;

    function isInCatalog(item) { 
        return item.productid != ''; 
    }


    function isInside(item) { 
            var x = item['x']/100;
            var y = item['y']/100;
            var p1 = {'x':15.47, 'y':24.53};
            var p2 = {'x':4.25, 'y':0.77};

        return p1['x'] > x && x > p2['x'] && p1['y'] > y && y > p2['y'];
    }  


    // Transformations to go from robot space to matterport space
    async function getTransformations() {
        var coords = await tfg.utility.readAndParseCSVFile("coordsEquivalent.csv", "eq.csv");
        console.log("coords: ", coords);
        coords = coords.map(c => {
            var v = {};
            v.r = new Vector(parseFloat(c["rX"]), parseFloat(c["rY"]));
            v["m"] = new Vector(parseFloat(c["mX"]), parseFloat(c["mZ"]));
            console.log("uveee:", v);
            return v;
        });

        var trans = {};
        // var u = coords[1].r.sub(coords[0].r);
        // var v = coords[1]["m"].sub(coords[0]["m"]);
        var robotAngle = coords[0].r.degreesTo(coords[1].r);
        var matterAngle = coords[0]["m"].degreesTo(coords[1]["m"]);

        trans["robot"] = coords[0].r;
        trans["matter"] = coords[0]["m"];
        trans["rotation"] = matterAngle - robotAngle;
        console.log("trans:", trans);
        return trans;
    }

    // Change item space from robot to matterport
    function toMatterCoords(item, trans) {
        var auxVec = new Vector(parseFloat(item['x']/100), parseFloat(item['y']/100));
        auxVec.subSelf(trans["robot"]);
        auxVec.rotateDegreesSelf(trans["rotation"]);
        auxVec.addSelf(trans["matter"]);
        item['x'] = auxVec['x'].toString();
        item['y'] = "1";
        item['z'] = auxVec['y'].toString();
        return item;
    }

    function distanceBetweenItems (item1, item2) {
        // console.log(item1['x'], item1['z']);
        var v1 = new Vector(item1['x'], item1['z']);
        var v2 = new Vector(item2['x'], item2['z']);
        // console.log(v1, v2);
        return v1.distanceFrom(v2);
    }

    const MIN_DIST = 4;

    function getClusteredTags(tags) { // Treure
        var currentCluster = 0;
        var unitaryClusters = true;
        var clusters = {};
        var epcs = Object.keys(tags);
        var remainingEpcs = epcs;
        while(remainingEpcs.length > 0) {
            currentCluster++;
            var neighbors = [];
            neighbors[0] = remainingEpcs[0];
            remainingEpcs.shift();
            var nb_id = 0;
            while(nb_id < neighbors.length) {
                var curr_nb = neighbors[nb_id];
                epcs.forEach(epc => {
                    if(epc != curr_nb && !neighbors.includes(epc) && distanceBetweenItems(tags[curr_nb], tags[epc]) < MIN_DIST) {
                        neighbors.push(epc);
                        remainingEpcs = remainingEpcs.filter(e => e != epc);
                    }
                })
                nb_id++;
            }

            clusters[currentCluster] = {};
            clusters[currentCluster]['info'] = {};
            clusters[currentCluster]['info']['x'] = 0.0;
            clusters[currentCluster]['info']['y'] = 0.0;
            clusters[currentCluster]['info']['z'] = 0.0;

            neighbors.forEach(epc => {
                clusters[currentCluster][epc] = tags[epc];
                clusters[currentCluster]['info']['x'] += tags[epc]['x'] / neighbors.length;
                clusters[currentCluster]['info']['y'] += tags[epc]['y'] / neighbors.length;
                clusters[currentCluster]['info']['z'] += tags[epc]['z'] / neighbors.length;
            })
            
            clusters[currentCluster]['info']['quantity'] = neighbors.length;
            clusters[currentCluster]['info']['misplaced'] = neighbors.length == 1 ? true : false;
            
            if (neighbors.length > 1) {
                unitaryClusters = false;  
            }
        }

        if (unitaryClusters) {
            Object.keys(clusters).forEach(c => {
                clusters[c]['info']['misplaced'] = false;
            })
        }

        return clusters;
    }

    return { 

        getInventory: async function () {
            if (inventory) return inventory;
            var trans = await getTransformations();
            try {

                const queryParams = new URLSearchParams({
                    token: 'testmaria',
                    shop: 'shop0',
                    reporttype: 'json',
                    othercolumns: 'x,y',
                    username: 'mfaramburu',
                    password: 'bn0V6Xm!',
                    type: 'RESULT'
                });
    
                const url = `https://testing.keonn.com/advancloud/import/stock/download?${queryParams}`;
    
                const response = await fetch(url);
    
                if (!response.ok) {
                    throw new Error('Failed to fetch inventory data');
                }
    
                const inventoryData = await response.json();
                console.log(inventoryData);

                inventory = {};

                inventoryData.data.forEach(async item => {

                    var sku = item.skuid;
    
                    if (filterByCatalog && !isInCatalog(item)) return;
                    if (filterOutside && !isInside(item)) return;

                    
                    const code = "0" + item.code; 

                    var key = code;

                    item = toMatterCoords(item, trans);
                
                    if (!inventory[key]) {
                        inventory[key] = {'info': {
                            "title": "",
                            "image": "",
                            "price": "",
                            "quantity": 1, 
                        }, 'tags': {}};

                    } else {

                        inventory[key]['info']['quantity'] += 1;

                    }

                    if (!inventory[key]['tags'][item.epc] || inventory[key]['tags'][item.epc]['times-read'] < item['times-read']) {
                        inventory[key]['tags'][item.epc] = {
                            'x': parseFloat(item['x']),
                            'y': parseFloat(item['y']),
                            'z': parseFloat(item['z']),
                            'times-read': parseInt(item['times-read'],10)
                        }
                    }
    
                })

                Object.keys(inventory).forEach(function (key) {
                    var item = inventory[key];
                    inventory[key]['tags'] = getClusteredTags(inventory[key]['tags']);
    
                });
                
                console.log("Inventory loaded:",inventory);
                return inventory;


            } catch (error) {
                console.error('Error fetching inventory:', error);
                throw error; 
            }
        }     
    };


})();