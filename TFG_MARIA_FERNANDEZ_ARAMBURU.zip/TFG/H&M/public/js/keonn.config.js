
var keonn=keonn || {};

keonn.config=keonn.config || (function(){
	
	'use strict';
	
	var properties={};
	
	var propertiesfrozen=null;
	
	if(keonn.util && keonn.util.getParameters)
		{
		var propertiesx=keonn.util.getParameters();
		
		for (var name in propertiesx) {
			  if (propertiesx.hasOwnProperty(name)) {
				  var value=propertiesx[name];
				  
				  if(value==='true')
					{
					properties[name]=true;
					}
				  	else
				  if(value==='false')
					{
					properties[name]=false;
					}
				  	else
				  if(keonn.util.isStringANumber(value))
					{
					properties[name]=parseFloat(value);
					}
				  	else
				  	{
				  	properties[name]=value;
				  	}
			  }
			}
		
		var token=keonn.util.getTokenFromUrl();
		
		properties.token=token;
		};
	
	return {
		setProperties: function(props){
			keonn.util.copyObjectProperties(properties,props);
			
			propertiesfrozen=null;
			},
			
		mergeProperties: function(props){
			
			var deferred = $.Deferred();
			
			var tmp={};
			
			keonn.util.mergeObjectProperties(tmp,properties);
			keonn.util.mergeObjectProperties(tmp,props);
						
			var appjsondeferred;
			
			if(keonn.kclient && keonn.kclient.isAvailable())
				{
				keonn.kclient.enableEvents();
				
				appjsondeferred = $.Deferred();
				
				keonn.kclient.getConfiguration(function(configxx){
										
					var dd=[];
					dd.push(JSON.parse(configxx));
					appjsondeferred.resolve(dd);
					});	
				}
				else
				{
				var appjsonurl=keonn.util.getServerFromUrl()+'/advancloud/publish/'+keonn.util.getTokenFromUrl()+'/appjson';
				
				if(properties.shop && !properties.useAppJson)
					{
					appjsonurl=appjsonurl+'?shop='+properties.shop;
					}
				
				appjsondeferred=$.getJSON(appjsonurl);
				}
			
			var calls=[appjsondeferred];
			
			var brandingvalue=tmp.branding;
			
			if(brandingvalue && brandingvalue!='')
				{
				var brandings=brandingvalue.split(',');
				brandings.reverse();
				var ldpath='';
				
				brandings.forEach(function(branding)
						{
						if(branding!='')
							{
							calls.push($.getJSON("branding/"+branding+"/config/config.json",{}));		
							}
						});
				}
			
			var callslength=calls.length;
			
			$.when.apply($,calls).then(function()
					{					
					try
						{
						var tmp2={};
												
						keonn.util.mergeObjectProperties(tmp2,properties);
						
						if(callslength>1)
							{
							for (var i = 0, len = arguments.length; i < len; i++)
								{
								var arga=arguments[i];
								var data;
								
								data=arga[0];
								
								if(data!=null && typeof data=='object')
									{
									keonn.util.mergeObjectProperties(tmp2,data);	
									}
									else
									{
									throw 'baddata';	
									}
								}
							}
							else
							{
							var data=arguments[0];
							
							if (data instanceof Array)
								{
								data=data[0];
								}
							
							if(data!=null && typeof data=='object')
								{
								keonn.util.mergeObjectProperties(tmp2,data);	
								}
								else
								{
								throw 'baddata';	
								}
							}
						
						keonn.util.mergeObjectProperties(tmp2,props);
						
						properties=tmp2;
						
						deferred.resolve(true);
						}
					catch(err)
						{
						deferred.reject();
						}
				},
				function(){
					deferred.reject();
				});
								
			
			return deferred.promise();
			},
			
		setProperty: function(key,value){
			properties[key]=value;
			
			propertiesfrozen=null;
			},
			
		getPropertiesMap: function()
		{
			if(propertiesfrozen==null)
				{
				var pp=keonn.util.deepClone(properties);
				
				// freeze recursively				
				propertiesfrozen=keonn.util.makeImmutable(pp);
				}
			
			return propertiesfrozen;
		},
				
	    getProperty: function(key,def){
	    	var v=properties[key];
	    	
	    	if(v==undefined && parent && parent!= window && parent['keonn'] && parent['keonn']['config'])
	    		{
	    		v=parent['keonn']['config']['getProperty'](key,def);
	    		}
	    	
	    	if(v==undefined)
	    		{
	    		v=def;
	    		}
	    	
	    	return v;
	    }
	};
})();

window['keonn']=keonn;
keonn['config']=keonn.config;
keonn.config[keonn.util.getClosureValue("getProperty")]=keonn.config.getProperty;

