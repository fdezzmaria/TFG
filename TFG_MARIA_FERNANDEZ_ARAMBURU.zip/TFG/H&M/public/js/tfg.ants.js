var tfg = tfg || {};

tfg.ants = tfg.ants || (function () {
    var ac = new AntColony();

    function populateGraph (items) {
        ac.getGraph().clear();
        for (const item of items) {
            ac.getGraph().addCity(item['sid'], item['x'], item['z']);
        }
        ac.getGraph().createEdges();
        ac.reset();
    }
    return {
        getBestPathForItemsList: function (items) {
            var visitedCodes = [];
            populateGraph(items);
            ac.run();
            // console.log("Iteration Best:"+JSON.stringify(ac.getIterationBest()));
            // console.log("Global Best:"+JSON.stringify(ac.getGlobalBest()));
            console.log(ac.getGlobalBest());
            var tour = ac.getGlobalBest().getTour().getTour();
            for (const city of tour) {
                visitedCodes.push(items.find(item => item['sid'] === city.getId()))
            }
            return visitedCodes;
        }
    }

})();

window['tfg']=tfg;
tfg['ants']=tfg.ants;