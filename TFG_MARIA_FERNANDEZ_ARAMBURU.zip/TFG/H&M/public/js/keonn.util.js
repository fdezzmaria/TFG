
var keonn=keonn || {};

keonn.util=keonn.util || (function(){
	
	'use strict';
	
	var inactivity=false;
	var interfalfunction;
	
	var dialogcount=0;
	
	var compiledtemplatebyid={};
	
	var theprotocol=window.location.protocol;
	var thehost=window.location['host'];
	var thepathname=window.location['pathname'];
	var thesearch=window.location['search'];
	
	var templatedocumentspath=[];
	
	var isapple=(/iphone|ipod|ipad/i.test(navigator.userAgent.toLowerCase()));
	
	var isdevelopment=(/kdevelopment/i.test(navigator.userAgent.toLowerCase()));
	
	var googledomains=null;
	
	var getRandomFromArray=function(urlxx,arr)
	{
		var hh=keonn.util.calculateHash(urlxx);

		hh=(Math.abs(hh))%arr.length;

		return arr[hh];
	}
	
	
	var scene7shardingdomains=null;
	
	var getRandomFromScene7Server=function(urlxx,iscontent)
	{
		if(scene7shardingdomains==null)
			{
			var scene7shardingdomainss=keonn.config.getProperty("scene7Domains","s7d9,s7d10");
			
			scene7shardingdomains=scene7shardingdomainss.split(",");
			}
		
		var retserver=getRandomFromArray(urlxx,scene7shardingdomains);
		var finalretserver=null;
		
		if(retserver.indexOf(':')!=-1)
			{
			finalretserver=retserver;
			}
			else
			{
			finalretserver="https://"+retserver+".scene7.com";
			}
		
		finalretserver=finalretserver+"/is/"+(iscontent?"content":"image")+"/LuckyBrandJeans/";
		
		return finalretserver;
	}
	
	var getScene7ActualParams=function(rurl,maxsize)
	{
		if(maxsize && maxsize!='none' && maxsize!=0)
			{
			if(maxsize==130)
				{
				return rurl+"?$catlookThumb$";
				}
				else
			if(maxsize==44)
				{
				return rurl+"?$prod_swatch$";
				}
				else
			if(maxsize==174)
				{
				return rurl+"?$catlookSaved$";
				}
				else
			if(maxsize==300)
				{
				return rurl+"?$catlookScanRec$";
				}
				else
				{
				return rurl+"?fit=constrain,1&wid="+maxsize+"&hei="+maxsize;
				}
			}
			else
			return rurl;
	}
	
	
	
	/* BACKGROUND IMAGE REPLACE */
	
	/*Handlebars.registerHelper('backimagestyle', function(url,failurl) {
	
	//url="http://localhost:8080/advancloud/webapp/logox";
			
	if(!failurl || failurl=="")
		{
		failurl='branding/lucky/img/clover.jpg';
		}
	
	var urls=encodeIntoCssUrl(url);
	
	urls=urls+", "+encodeIntoCssUrl(failurl);
	
	return new Handlebars.SafeString(" style=\"background-image: "+urls+"\" ");
	
	});*/

	var encodeIntoCssUrl=function(url){
		
		return "url('"+url+"')";
	};
	
	var replaceBackgroundFromDom=function(backimageid,url){
		
		var urls=encodeIntoCssUrl(url);
		
		$("[data-kbackimageid='"+backimageid+"']").css("background-image",urls).removeAttr("data-kbackimageid");
	};
	
	var loadBackgroundFromDom=function(backimageid,url,failurl){
		var image = new Image();
		
		image.onload = function() {
			replaceBackgroundFromDom(backimageid,url);
	    };
	    
	    image.onerror = function() {
	    	
	    	if(!failurl || failurl=="")
				{
	    		failurl=keonn.config.getProperty('imageDefaultErrorPlaceholder');
				}
	    	
	    	replaceBackgroundFromDom(backimageid,failurl);
	    };
	    
	    image["src"] = url;
	};
	
	
	

	if(typeof Handlebars !== 'undefined')
		{
		Handlebars.registerHelper('formatdate', function(dateTime, dateFormat) {
			if (typeof dateFormat != 'string') {
				dateFormat = keonn.config.getProperty('formatDateDefaultFormat', 'dd/mm/yy');
			}
			var d = $.datepicker["formatDate"](dateFormat, new Date(dateTime['__d']));
			if (keonn.config.getProperty('expirationTimeEnable') && dateTime['__t'] != null) {
				d += " " + dateTime['__t'];
			}
			return d;
			});
		
		Handlebars.registerHelper('formatimageurl', function(url,maxsize) {
			
			if(typeof maxsize=="object")
				maxsize=undefined;
			
			return keonn.util.calculateFinalUrl(url,maxsize);
			});

		Handlebars.registerHelper('formaturl', function(url) {
			
			return keonn.util.getServerFromUrl()+url;
			});
		
		Handlebars.registerHelper('debug', function(data) {
			
			console.log(data);
			
			return '';
			});
		
		Handlebars.registerHelper('resourcethumbnail', function(resource,maxsize) {
			
			if(resource.resourcetype=='image')
				{
				return keonn.util.calculateFinalUrl(resource.url,maxsize);	
				}
				else
			if(resource.resourcetype=='video')
				{
				return keonn.util.calculateFinalVideoThumbnailUrl(resource.url,maxsize);
				}
				else
			if(resource.resourcetype=='book3d')
				{
				return "img/book3d.png";
				}
				else
			if(resource.resourcetype=='images360')
				{
				return "img/images360.png";
				}
				else
				throw 'unknownresourcetype';
			});
		
		Handlebars.registerHelper('resourcedata', function(resourceurl,resourcetype,op,maxsize) {
			
			if(op=='thumbnail')
				{
				if(resourcetype=='image')
					{
					return keonn.util.calculateFinalUrl(resourceurl,maxsize);	
					}
					else
				if(resourcetype=='video')
					{
					return keonn.util.calculateFinalUrl(resourceurl+"?op=thumbnail&maxsize="+maxsize);
					}
					else
					throw 'unknownresourcetype';
				}
				else
			if(op=='url')
				{
				if(resourcetype=='image')
					{
					throw 'notimplemented';
					}
					else
				if(resourcetype=='video')
					{
					return keonn.util.calculateFinalUrl(resourceurl);
					}
					else
					throw 'unknownresourcetype';
				}
				else
				throw 'unknownop';
			});
		
		if(typeof marked !== 'undefined')
			{
			marked.setOptions({
				  sanitize: true
				});
			
			Handlebars.registerHelper('markdown', function(md) {
				
				if(md)
					{
					return new Handlebars.SafeString(marked(md));
					}
					else
					{
					return '';
					}
				});
			}
		
	
			
			
			
			/* BACKGROUND IMAGE REPLACE */
			
			Handlebars.registerHelper('backimagestyle', function(url,failurl) {
				
				var backimageid=keonn.util.randomStringAlpha(8);
				
				setTimeout(function(){
					loadBackgroundFromDom(backimageid,url,failurl);
				},0);
				
				return new Handlebars.SafeString(" data-kbackimageid=\""+backimageid+"\"");
				
				});
			
			
			
			Handlebars.registerHelper('underscoreattribute', function(property,underscore) {
				
				var retval;
				
				if(underscore)
					{
					var propname=property+"_"+underscore;
					
					if(this.hasOwnProperty(propname))
						{
					    return new Handlebars.SafeString(this[propname]);
						}
					}
				
				return this[property];
				});
			
		}
	
	var touched=Date.now();

	/* LRU CACHE */
	
	var LRUCache = function LRUCache (limit,timetolive,asjson) {
		  // Current size of the cache. (Read-only).
		  this.size = 0;
		  // Maximum number of items this cache can hold.
		  this.limit = limit;
		  this.timetolive=timetolive || (3600*1000);
		  this.asjson=asjson;
		  this._keymap = {};
		}

		LRUCache.prototype = {
			put: function(key, value) {

			this.putReal(key,this.asjson?JSON.stringify(value):value);
			},

			putAsJSON: function(key, json) {

			if(!this.asjson)
				throw "NOTASJSON";
				
			this.putReal(key,json);
			},
			
			putReal: function(key, value)
			{
			// F
			// remove preventively to avoid orphans 
			this.remove(key);
			
		  var entry = {key:key, value: value, touched: Date.now()};
		  // Note: No protection agains replacing, and thus orphan entries. By design.
		  this._keymap[key] = entry;
		  if (this.tail) {
		    // link previous tail to the new tail (entry)
		    this.tail.newer = entry;
		    entry.older = this.tail;
		  } else {
		    // we're first in -- yay
		    this.head = entry;
		  }
		  // add new entry to the end of the linked list -- it's now the freshest entry.
		  this.tail = entry;
		  if (this.size === this.limit) {
		    // we hit the limit -- remove the head
		    return this.doshift();
		  } else {
		    // increase the size counter
		    this.size++;
		  }
		},
		
		// F
		// removing items
		remove: function(key){
			if (this._keymap.hasOwnProperty(key))
				{
				 var currentry=this._keymap[key];
				 
				 var newer=currentry.newer;
				 var older=currentry.older;
				 
				 if(newer && older)
					 {
					 newer.older=older;
					 older.newer=newer;
					 }
				 	else
				 if(!newer && older)
					 {
					 // tail
					 this.tail=older;
					 older.newer=undefined;
					 }
				 	else
				if(newer && !older)
					 {
					 //header
					this.head=newer;
					newer.older=undefined;
					 }
					else
					{
					this.head=undefined;
					this.tail=undefined;
					}
				
				delete this._keymap[key];
				 
				this.size--;
			  	}
		},

			doshift: function() {
		  // todo: handle special case when limit == 1
		  var entry = this.head;
		  if (entry) {
		    if (this.head.newer) {
		      this.head = this.head.newer;
		      this.head.older = undefined;
		    } else {
		      this.head = undefined;
		    }
		    // Remove last strong reference to <entry> and remove links from the purged
		    // entry being returned:
		    entry.newer = entry.older = undefined;
		    // delete is slow, but we need to do this to avoid uncontrollable growth:
		    delete this._keymap[entry.key];
		  }
		  return entry;
		},

		get: function(key) {
		  // First, find our cache entry
		  var entry = this.getEntryWithoutUpdating(key);
		  
		  if(!entry)
		  	{
		  	return;
		  	}
		  
		  // As <key> was found in the cache, register it as being requested recently
		  if (entry === this.tail) {
		    // Already the most recenlty used entry, so no need to update the list
		    return this.asjson?JSON.parse(entry.value):entry.value;
		  }
		  // HEAD--------------TAIL
		  //   <.older   .newer>
		  //  <--- add direction --
		  //   A  B  C  <D>  E
		  if (entry.newer) {
		    if (entry === this.head)
		      this.head = entry.newer;
		    entry.newer.older = entry.older; // C <-- E.
		  }
		  if (entry.older)
		    entry.older.newer = entry.newer; // C. --> E
		  entry.newer = undefined; // D --x
		  entry.older = this.tail; // D. --> E
		  if (this.tail)
		    this.tail.newer = entry; // E. <-- D
		  this.tail = entry;
		  return this.asjson?JSON.parse(entry.value):entry.value;
		},
		
		getEntryWithoutUpdating: function(key){
		
			var entry = this._keymap[key];
		  if (entry === undefined) return; // Not cached. Sorry.
		  
		  var now=Date.now();
		  var entrynow=entry.touched;
		  var diff=now-entrynow;
		  
		  if(diff>this.timetolive)
		  	{
		  	return;
		  	}
		  	
			return entry;		  	
		},

		cleanAll: function() {
		  // This should be safe, as we never expose strong refrences to the outside
		  this.head = this.tail = undefined;
		  this.size = 0;
		  this._keymap = {};
		},
		
		getAllValues: function(){
			var retval=[];
			
			for (var key in this._keymap) {
				  if (this._keymap.hasOwnProperty(key)) {
				  
				  	var entry=this.getEntryWithoutUpdating(key);
				  	
				  	if(entry)
				  		{
				  		retval.push(this.asjson?JSON.parse(entry.value):entry.value);
				  		}
				  }
				}
				
			return retval;
		},

		toJsonObject: function()
		{
			var retval = [];

			if (this.head)
			{
				retval.push({key: this.head.key, value: this.head.value})

				var current = this.head.newer;

				while (current != null)
				{
					retval.push({key: current.key, value: current.value});
					current = current.newer;
				}
			}

			return JSON.stringify(retval);
			
		},

		fromJsonObject: function(obj)
		{
			var parsedObj = JSON.parse(obj);

			for (var i=(parsedObj.length-1); i>=0; --i)
			{
				this.putAsJSON(parsedObj[i].key, parsedObj[i].value);
			}
		}
	};
	
	// HASHCODE
	
	// Hashes a string
    var hash = function(string)
    {
        var string = string.toString(), hash = 0, i;
        for (i = 0; i < string.length; i++)
        {
            hash = (((hash << 5) - hash) + string.charCodeAt(i)) & 0xFFFFFFFF;
        }

        return hash;
    };
    // Deep hashes an object
    var object = function(obj)
    {
        var result = 0;
        for(var property in obj)
        {
            if(obj.hasOwnProperty(property))
            {
                result += hash(property + value(obj[property]));
            }
        }
        
        return result;
    };
    // Does a type check on the passed in value and calls the appropriate hash method
    var value = function(value)
    {
        var types =
        {
            'string' : hash,
            'number' : hash,
            'boolean' : hash,
            'object' : object
            // functions are excluded because they are not representative of the state of an object
            // types 'undefined' or 'null' will have a hash of 0
        };
        var type = typeof value;
        
        // F auto convert to string
        if(type=='number')
        	{
        	value=''+value;
        	type = typeof value;
        	}
        
        return value != null && types[type] ? types[type](value) + hash(type) : 0;
    };
	
	
    /* MUTATION OBSERVER */
    
    var removalFunction=function(nodex,fromobserver)
    {    	
    	$(document).trigger('kremoved',nodex);
    	
    	nodex.removeAttribute('data-knotify');
    };
    
    var removalTreeFunction=function(node,fromobserver)
    {
    	var $node=$(node);
		
		$node.find('[data-knotify]').each(function(idx,nodex){
			removalFunction(nodex,fromobserver);
		});
		
        if(node.hasAttribute("data-knotify"))
        	{
        	removalFunction(node,fromobserver);
        	}
    };
    
    if(typeof MutationObserver !== 'undefined')
		{
	    var obs = new MutationObserver(function(mutations, observer) {
	
	        for(var i=0; i<mutations.length; i++)
	        	{
	        	var mutation=mutations[i];
	
	        	/*
	            // look through all added nodes of this mutation
	            for(var j=0; j<mutation.addedNodes.length; ++j)
	            	{
		    		var node=mutations[i].addedNodes[j];
		
				    if(node.nodeType==Node.ELEMENT_NODE)
				    	{		
			                if(node.hasAttribute("data-knotify"))
				                {
					    		var ktype=node.getAttribute("data-knotify");
					    		$(document).trigger('kadded.'+ktype,node);
					    		$(document).trigger('kadded!',node);
				                }
				    	}
		            }
				*/
	
		    	for(var j=0; j<mutation.removedNodes.length; j++)
		    		{
		    		var node=mutations[i].removedNodes[j];
		
		    		if(node.nodeType==Node.ELEMENT_NODE)
		    			{
		    			removalTreeFunction(node,true);
		    			}
		    		}
	        	}
	    
	    });
	    
	    $(function() {
	    	// have the observer observe foo for changes in children
	        obs.observe( document.body, {
	        	childList: true,
	        	subtree: true
	        });
	    });
    
		};

	return {
		getVersion: function(){
				return '1.0';
			},
			
		LRUCache: LRUCache,
			
	    confirm: function(msg,redefinekey){
	    	return this.createConfirmOrAlert(msg,true,redefinekey);
	    },
	    
	    alert: function(msg,redefinekey){
			return this.createConfirmOrAlert(msg,false,redefinekey);
		},
		
		searchForRedefinedTemplate: function(thetype,redefinekey){
			
			var base="redefine_"+thetype;
			
			if(redefinekey)
				{
				var comp=base+"_"+redefinekey.replace(/[.]/g,'_');
				
				if(this.getExistsTemplateForTemplateId(comp))
					{
					return comp;
					}
				}
			
			if(this.getExistsTemplateForTemplateId(base))
				{
				return base;
				}
			
			return null;
		},
	    
	    createConfirmOrAlert: function(msg,isconfirm,redefinekey){
	    	var dialogid="keonnConfirmDialog"+dialogcount++;
	    	var dialogidok=dialogid+"ok";
	    	var dialogidcancel=dialogid+"cancel";
	    	
	    	var deferred = $.Deferred();
	    	var templateid=this.searchForRedefinedTemplate(isconfirm?"confirm":"alert",redefinekey);
	    	
	    	var dtxt="";
	    	
	    		
	    	if(templateid!=null)
	    		{
	    		var props={};
	    		
	    		props.dialogid=dialogid;
	    		props.message=msg;
	    		props.redefinekey=redefinekey;

	    		dtxt=this.formatTemplateWithObject(templateid,props).trim();
	    		}
	    		else
	    		{
	    		var addclass="ui-corner-all";
	    			
    			if(redefinekey)
    				{
    				addclass=addclass+" "+redefinekey.replace(/[.]/g,'_');
    				}
	    			
	    		dtxt='<div data-role="popup" id="'+dialogid+'" data-overlay-theme="a" data-theme="c" data-dismissible="false" style="max-width:400px;" class="'+addclass+'">'
			        +'<div data-role="content" data-theme="d" class="ui-corner-bottom ui-content">'
			            +'<h3 class="ui-title">'+msg+'</h3>';
	    	
		    	if(isconfirm)
		    		{
		    		dtxt=dtxt+'<a data-role="button" class="dialogko" data-inline="true" data-theme="c">'+keonn.ld.getLDToken('keonn.confirm.cancel')+'</a>';
		    		}
		    	
		    	dtxt=dtxt+'<a data-role="button" class="dialogok" data-inline="true" data-transition="flow" data-theme="b">'+keonn.ld.getLDToken('keonn.confirm.ok')+'</a>'
				        +'</div>'
				    	+'</div>';		
	    		}
	    	
	    	var popupTransition=keonn.config.getProperty("popupTransition","pop");
	    	
	    	var resultvalue;
	    	var closePopupWithResult=function(result){
	    		resultvalue=result;
	    		try {
					$popUp.popup("close");
					$popUp.popup("close");
				}
				catch (e) {
					console.log(e);
				}
	    	};
	    	
	    	var $popUp = $(dtxt).popup({
	            dismissible : false,
	            theme : "c",
	            overlyaTheme : "a",
	            transition : popupTransition
	        }).bind("popupafterclose", function(){
				$(this).remove();
				deferred.resolve(resultvalue);
			});
	    	
	    	this.setFormattedTemplateContentProcessIncludes($popUp,props);
	    	  	
	    	$popUp.popup("open").trigger('create');
	    	
			$('#'+dialogid+" .dialogok").on("tap",function(){
				closePopupWithResult(true);
			});
			
			if(isconfirm)
			{
				$('#'+dialogid+" .dialogko").on("tap",function(){
					closePopupWithResult(false);
				});
			}
			
			return deferred.promise();
		},
	    
	    confirmld: function(ldkey,parameters,redefinekey){
	    	return this.confirm(keonn.ld.getLDToken(ldkey,parameters),redefinekey || ldkey);
	    },
		
		alertld: function(ldkey,parameters,redefinekey){
			return this.alert(keonn.ld.getLDToken(ldkey,parameters),redefinekey || ldkey);
		},

		toastld: function(ldkey,parameters,redefinekey){
			
			var toastdisable;
			var toastdelay;
			
			if(keonn.config)
				{
				toastdisable=keonn.config.getProperty("toastDisable_"+ldkey.replace(/[.]/g,'_'),false);
				
				if(toastdisable)
					{
					var deferred = $.Deferred();
					
					deferred.resolve(true);
					
					return deferred.promise();
					}
				
				toastdelay=keonn.config.getProperty("toastTimeout_"+ldkey.replace(/[.]/g,'_'));
				}
			
			return this.toast(keonn.ld.getLDToken(ldkey,parameters),redefinekey || ldkey,toastdelay);
		},
		
		toast: function(msg,redefinekey,toastdelay){
			
			var toastTimeout;
			
			if(keonn.config)
				{
				toastTimeout=keonn.config.getProperty("toastTimeout");
				}
			
			var toastTimeoutr=toastdelay || toastTimeout || (1500);
			
			var deferred = $.Deferred();
			var templateid=this.searchForRedefinedTemplate("toast",redefinekey);
			
			var dtxt="";
			var cssprops;
			
			if(templateid!=null)
	    		{
	    		var props={};
	    		
	    		props.message=msg;
	    		props.redefinekey=redefinekey;
	
	    		dtxt=this.formatTemplateWithObject(templateid,props).trim();
	    		
	    		cssprops={};
	    		}
	    		else
    			{
	    		dtxt="<div class='ui-loader ui-overlay-shadow ui-body-e ui-corner-all ktoast'><h3>"+msg+"</h3></div>";
	    		
	    		cssprops={ display: "block", 
					opacity: 0.90, 
					position: "fixed",
					padding: "7px",
					"text-align": "center",
					width: "270px",
					left: ($(window).width() - 284)/2,
					top: $(window).height()/2 };
    			}
		
			var container;
			
			if($.mobile && $.mobile.pageContainer)
				{
				container=$.mobile.pageContainer;
				}
				else
				{
				container=document.body;
				}
			
			$(dtxt)
			.css(cssprops)
			.appendTo(container).delay( toastTimeoutr )
			.fadeOut(3000 , function(){
				$(this).remove();
				
				deferred.resolve(true);
			});
			
			return deferred.promise();
		},

		getParametersFromQuery: function(searchString) {
		  var params = searchString.split("&")
		    , hash = {}
		    ;
		
		  for (var i = 0; i < params.length; i++) {
		    var val = params[i].split("=");
		    hash[unescape(val[0])] = unescape(val[1]);
		  }
		  return hash;
		},

		getParameters: function() {
		  var paramq=thesearch;
		  
		  if(paramq.length>1)
			return this.getParametersFromQuery(paramq.substring(1));
		  	else
		  	return {};
		},
		
		getTokenFromUrl: function(){
			var pn=thepathname;
			var pna=pn.split("/");
			
			var idx=pna.indexOf('publish');
			
			if(idx!=-1)
				{
				var tt=pna[idx+1];
				
				var roots=['product','template'];
				
				if(roots.indexOf(tt)!=-1)
					{
					return pna[idx+2];
					}
				}
				
			var params=this.getParameters();
			
			var token=params.token;

			if (token) {
				return token;
				}
				else
				{
				var baselem=document.getElementById("baseforinline");
		  		
		  		if(baselem)
		  			{
		  			return baselem.dataset.apptoken;
		  			}
		  			else
		  			{
					throw "cannot find token";
					}
				}
		},

		getHostFromUrl: function(){
			if (theprotocol == 'file:')
				{
				var params=this.getParameters();

				var host=params['host'];

				if (host) {
					return host;
					}
					else
					{
					throw "cannot find host";
					}
				}
				else
			if(isdevelopment)
				{
				var params=this.getParameters();

				var host=params['host'];

				if (host) {
					return host;
					}
					else
					{
					return thehost;
					}
				}
				else
				{
				return thehost;
				}
		},
		
		getProtocolFromUrl: function(){
			if (theprotocol == 'file:')
				{
				var params=this.getParameters();
	
				var protocol=params[this.getClosureValue('protocol')]||'http';
	
				return protocol+':';
				}
				else
			if (isdevelopment)
				{
				var params=this.getParameters();
	
				var protocol=params[this.getClosureValue('protocol')];
				
				if(protocol)
					{
					return protocol+':';
					}
					else
					{
					return theprotocol;
					}
				}
				else
				{
				return theprotocol;
				}
		},

		getServerFromUrl: function(){					
			return this.getProtocolFromUrl()+'//'+this.getHostFromUrl();
		},
		
		getIndexOfArrayInArray: function(bigarr,arr){
			
			for(var i=0;i<bigarr.length-arr.length;i++)
				{
				var matches=true;
				
				for(var j=0;j<arr.length;j++)
					{
					if(bigarr[i+j]!=arr[j])
						{
						matches=false;
						}
					}
					
				if(matches)
					return i;
				}
				
			return -1;
		},

		getParametersFromUrl: function(curl) {
		    var questionidx=curl.indexOf("?");
		
		        if(questionidx!=-1)
		            {
		            var url=curl.substring(questionidx+1);
		
		            return utils_getParametersFromQuery(url);
		            }
		            else
		            {
		            return {};
		            }
		},

		randomString: function(strLength, charSet) {
		    var result = [];
		
		    strLength = strLength || 5;
		    charSet = charSet || 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		
		    while (--strLength) {
		        result.push(charSet.charAt(Math.floor(Math.random() * charSet.length)));
		    }
		
		    return result.join('');
		},

		randomStringAlpha: function(strLength) {
		    return this.randomString(strLength,"ABCDEFGHIJKLMNOPQRSTUVWXYZ");
		},

		copyObjectProperties: function(toobj,fromobj){
			for (var name in fromobj) {
				  if (fromobj.hasOwnProperty(name)) {
				    toobj[name]=fromobj[name];
				  }
				}
		},
		
		getObjectPropertiesKeys: function(fromobj){
			
			var retval=[];
			
			for (var name in fromobj) {
				  if (fromobj.hasOwnProperty(name)) {
				    retval.push(name);
				  }
				}
			
			return retval;
		},
		
		mergeObjectProperties: function(toobj,fromobj){
			for (var name in fromobj) {
				  if (fromobj.hasOwnProperty(name) && !toobj.hasOwnProperty(name)) {
				    toobj[name]=fromobj[name];
				  }
				}
		},
		
		compareObjectProperties: function(obj1,obj2){
			return this.allObjectPropertiesIn(obj1,obj2) && this.allObjectPropertiesIn(obj2,obj1);
		},
		
		allObjectPropertiesIn: function(obj1,obj2){
			for (var name in obj1) {
				  if (obj1.hasOwnProperty(name)) {
					  
					  if (!obj2.hasOwnProperty(name))
						  {
						  return false;
						  }
					  
					if(obj1[name]!=obj2[name])
						return false;
				  }
				}
			
			return true;
		},
		
		countObjectProperties: function(obj1){
			var count=0;
			
			for (var name in obj1) {
				  if (obj1.hasOwnProperty(name)) {
					  
					 count++;
				  }
				}
			
			return count;
		},
		
		flash: function(id)
		{
			var $el=null;
			
			if($.type(id)==='string')
				{
				$el=$('#'+id+',.'+id);
				}
				else
				{
				$el=id;	
				}
			
			if($el.length>0)
				{
				var $sub=$el.find(".flashable");
				
				if($sub.length==1)
					$el=$sub;
				
				$el.removeClass("notifynew");
				
				window.setTimeout(function(){$el.addClass("notifynew");},10);
				
				window.setTimeout(function(){$el.removeClass("notifynew");},5000);
				}
		},
		
		animatedEntry: function(id)
		{
			var $el=null;
			
			if($.type(id)==='string')
				{
				$el=$('#'+id+',.'+id);
				}
				else
				{
				$el=id;	
				}
			
			if($el.length>0)
				{
				var maxadmin=6;
				
				var animidx=Math.floor((Math.random()*maxadmin));
				
				$el.removeClass("adminnew0 adminnew1 adminnew2 adminnew3 adminnew4 adminnew5").hide();
				
				var newanim='adminnew'+animidx;
				
				window.setTimeout(function(){$el.show().addClass(newanim);},10);
				
				window.setTimeout(function(){$el.removeClass(newanim);},2000);
				}
		},
		
		
		setTemplateDocumentsPath: function(documentspath)
		{
			templatedocumentspath=documentspath;
		},
		
		getTemplateHTMLForTemplateId: function(templateid)
		{
			var index, len;
			
			for (index = 0, len = templatedocumentspath.length; index < len; ++index)
				{
				var doc=templatedocumentspath[index];
				var el=doc.getElementById(templateid);
				
				if(el!=null)
					{
					var elinner=el.innerHTML;
					
					if(elinner==undefined)						
						{
						// bb does not support HTMLDocuments
						var s = new XMLSerializer();
						var str = s.serializeToString(el);
						 
						var div = document.createElement("div");
						div.innerHTML = str;
						elinner = div.getElementsByTagName('script')[0].innerHTML;
						}
					
					return elinner;
					}
				}
			
			return $("#"+templateid).html();
		},
		
		getExistsTemplateForTemplateId: function(templateid)
		{
			var index, len;
			
			for (index = 0, len = templatedocumentspath.length; index < len; ++index)
				{
				var doc=templatedocumentspath[index];
				var el=doc.getElementById(templateid);
				
				if(el!=null)
					{
					return true; 
					}
				}
			
			return $("#"+templateid).length>0;
		},
		
		formatTemplateWithObject: function(templateid,obj)
		{
			var compiledtemplate=compiledtemplatebyid[templateid];
			
			if(!compiledtemplate)
				{
				compiledtemplate=Handlebars.compile(this.getTemplateHTMLForTemplateId(templateid));
				
				compiledtemplatebyid[templateid]=compiledtemplate;
				}

			var tobj=Object.create(obj);

			tobj.config__=keonn.config.getPropertiesMap();

			tobj['urlbase']=this.getServerFromUrl();

			return compiledtemplate(tobj);
		},
		
		setFormattedTemplateContent: function(templateid,obj,targetid,replace)
		{
			var html=this.formatTemplateWithObject(templateid,obj);
			var $el;
			
			if($.type(targetid)==='string')
				{
				$el=$(targetid);
				}
				else
				{
				$el=targetid;	
				}
			
			var thiso=this;
			
			var updated=[];
			
			$el.each(function (index,el){
				if(thiso.setFormattedTemplateContentIntoElement(templateid,obj,el,replace))
					updated.push(el);
			});
			
			return $(updated);
		},
		
		setFormattedTemplateContentIntoElement: function(templateid,obj,el,replace)
		{		
			var thiso=this;
			
			var $template=$("#"+templateid);
			
			var exp=$template.data('updatechangeexp');
			
			if(exp)
				{
				var newval=this.calculateUpdateChangeExpression(obj,exp);
				var lastval=$(el).data("updatechangeval");
				
				if(newval!=lastval)
					{
					$(el).data("updatechangeval",newval);
					}
					else
					{
					return false;
					}
				}
			
			var html=this.formatTemplateWithObject(templateid,obj);
			
			var destroyval=null;
			
			var destroyfunction=$template.data("updatedestroyfunction");
			
			if(destroyfunction)
				{
				destroyval=destroyfunction(el);
				}
			
			var $el=$(el);
			
			$el.trigger('ktemplateend').each(function(idx,el){removalTreeFunction(el,false);});
			
			var $notifyel=$el;
			
			if(replace)
				{
				$notifyel=$el.parent();
				$el.replaceWith(html);
				}
				else
				{
				$el.html(html);
				}
			
			this.setFormattedTemplateContentProcessIncludes($el,obj);
			
			$el.trigger('ktemplatestart');
			
						
			$notifyel.trigger('kdomupdate');
						
			var initfunction=$template.data("updateinitfunction");
			
			if(initfunction)
				{
				initfunction(el,destroyval);
				}
			
			$el.trigger('relang');
			
			return true;
		},
		
		setFormattedTemplateContentProcessIncludes: function($el,obj)
		{
			var thiso=this;
			
			$el.find('[data-krole=include]').each(function(idx,elx){
				
				var $elx=$(elx);
				var updatetemplate=$elx.attr('data-updatetemplate');
				var htmlx;
				
				if(updatetemplate.indexOf('#')==0)
					{
					htmlx=$(updatetemplate).html();
					}
					else
					{
					htmlx=thiso.formatTemplateWithObject(updatetemplate,obj);	
					}
				
				if(htmlx)
					{
					$elx.html(htmlx);
					}
			});
		},
			
		calculateUpdateChangeExpression: function(obj,exp)
		{
			var newval=obj[exp];
			
			if(!newval)
				{
				newval='';
				}
				else
				{
				newval=this.calculateHash(newval);
				}
			
			return newval;
		},
		
		removeComponentsFromRoot: function(node)
		{
			removalTreeFunction(node,false);
		},
		
		/* INACTIVITY TIMEOUT */
		
		setInactivityTimeout: function(callback,timeout)
		{	
			var configtimeout;
			var configresolution;
			var configstartOn=false;
			
				if(keonn.config)
					{
					configtimeout=keonn.config.getProperty("inactivityTimeout");
					configresolution=keonn.config.getProperty("inactivityTimeoutCheck");
					configstartOn=keonn.config.getProperty("inactivityTimeoutStartOn");
					}					
				
			var intimeout=timeout || configtimeout || (5*60000); // 5 minutes
			var timerresolution=configresolution || 10000;  // 10 seconds
			
			
			interfalfunction=function(){
				var timesincetouched=Date.now()-touched;
				
				if(timesincetouched>intimeout)
					{
					touched=Date.now();
					
					if(!inactivity)
						{
						inactivity=true;
					
						callback(inactivity);
						}
					}
			};
			
			var touchfunction=function(){
				
				if(inactivity)
					{
					inactivity=false;
				
					callback(inactivity);
					}
				
				touched=Date.now();
			};
			
			var idleInterval = window.setInterval(interfalfunction, timerresolution);
			
			$(document).on("mousemove keydown DOMMouseScroll mousewheel mousedown touchstart touchmove inactivityTimeoutKeonn",touchfunction);
			
			var timeoutdata={
					intervalid: idleInterval,
					callback: touchfunction
			};
			
			if(configstartOn)
				{
				touched=0;
				
				setTimeout(interfalfunction,0);
				}
			
			return timeoutdata;
		},
		
		touchInactivityTimeout: function(){
			$.event.trigger({
				type: "inactivityTimeoutKeonn"
			});	
		},
		
		removeInactivityTimeout: function(timeoutdata)
		{
			window.clearInterval(timeoutdata.intervalid);
			
			$(document).off("mousemove keydown DOMMouseScroll mousewheel mousedown touchstart touchmove inactivityTimeoutKeonn",timeoutdata.callback);
		},
		
		launchInactivityTimeout: function()
		{
			touched=0;
			
			setTimeout(interfalfunction,0);
		},
		
		isInInactivityTimeout: function()
		{
			return inactivity;
		},
		
		
		getCdnProviderVideo: function()
		{			
			var cdnProvider=keonn.config.getProperty("cdnProviderVideo","auto");
			
			if(cdnProvider=='auto')
				{
				cdnProvider=keonn.config.getProperty("cdnProvider");
				}
			
			return cdnProvider;
		},
		
		
		calculateFinalVideoUrl: function(url)
		{
			var thiso=this;
			
			var processDefault=function(url){
				
				if(url.indexOf('http://')==-1 && url.indexOf('https://')==-1)
					{
					var token=thiso.getTokenFromUrl();
					
					return keonn.util.getServerFromUrl()+'/advancloud/publish/file/'+token+'/'+url;		
					}
					else
					{
					return url;
					}
			};
			
			
			var cdnProvider=this.getCdnProviderVideo();
			
			if(cdnProvider=='custom')
				{
				if(window.customVideoUrlResolve)
					{
					var retval=window.customVideoUrlResolve(url);
					
					if(retval!=null)
						{
						return retval;
						}
					}
					
				return processDefault(url);
				}
				else
			if(cdnProvider=='scene7')
				{
				var domain=getRandomFromScene7Server(url,true);
				
				return domain+url;
				}
				else
			if(cdnProvider=='alibaba')
				{
				return processDefault(url);
				}
				else
				{
				return processDefault(url);
				}
		},
		
		
		calculateFinalVideoThumbnailUrl: function(url,maxsize)
		{
			var cdnProvider=this.getCdnProviderVideo();
			var thiso=this;
			
			var processDefault=function(url,maxsize)
			{
				var token=thiso.getTokenFromUrl();
				
				url='/advancloud/publish/file/'+token+'/'+url+'?op=thumbnail';		
					
				var rurl=keonn.util.getServerFromUrl()+url;
			
				if(maxsize && maxsize!='none' && maxsize!=0)
					return rurl+"&maxsize="+maxsize;
					else
					return rurl;
			};
			
			
			if(cdnProvider=='custom')
				{
				if(window.customVideoThumbnailUrlResolve)
					{
					var retval=window.customVideoThumbnailUrlResolve(url,maxsize);
					
					if(retval!=null)
						{
						return retval;
						}
					}
				
				return processDefault(url);
				}
				else
			if(cdnProvider=='scene7')
				{
				// lucky brand only
				var key1='Videos/';
				var key2='.mp4';
				
				var idx=url.indexOf(key1);
				
				if(idx==0)
					{
					var idxbase=idx+key1.length;
					
					var videonamestart=url.substring(idxbase);
					
					var idx2=videonamestart.indexOf(key2);
					
					if(idx2!=-1)
						{
						var videoname=videonamestart.substring(0,idx2);
						
						var domain=getRandomFromScene7Server(videoname,false);
						
						var rurl=domain+videoname;
						
						return getScene7ActualParams(rurl,maxsize);
						}
					}
				
				
				return "/advancloud/images/filmstrip.png";
				}
				else
			if(cdnProvider=='alibaba')
				{
				return processDefault(url,maxsize);
				}
				else
				{
				return processDefault(url,maxsize);		
				}
		},
		
		getGoogleUrlDomainFromUrl: function(url)
		{
			if(googledomains==null)
				{
				googledomains=keonn.config.getProperty("googleDomains",".ggpht.com/,.googleusercontent.com/").split(',');
				}
			
			for(var i=0;i<googledomains.length;i++)
				{
				var gdomain=googledomains[i];
				
				if(url.indexOf(gdomain)!=-1)
					{
					return gdomain;
					}
				}
			
			return null;
		},
		
		getResourceFileUrl: function(url)
		{
			var token=this.getTokenFromUrl();
			
			var urlx='/advancloud/publish/file/'+token+'/'+url;		
			
			return keonn.util.getServerFromUrl()+urlx;
		},
		
		calculateFinalUrl: function(url,maxsize)
		{					
			if(!url)
				{
				url="/advancloud/images/noimage.svg";
				}
			
			if(url.indexOf('/advancloud/images/noimage.')==0)
				{
				var imagesNotFoundUrl=keonn.config.getProperty("imagesNotFoundUrl");
				
				if(imagesNotFoundUrl)
					{
					// relative to current url, if in branding then just dispatch
					// if not in branding it is in files
					
					if(imagesNotFoundUrl.indexOf('branding/')==0)
						{
						return imagesNotFoundUrl;
						}
						else
						{
						url=imagesNotFoundUrl;
						}
					}
				}
			
			var serverurl=keonn.util.getServerFromUrl();
			
			if(serverurl.length>0 && url.indexOf(serverurl)==0)
				{
				if(maxsize && maxsize!='none')
					return url+"?maxsize="+maxsize;
					else
					return url;
				}
				else
			if(url.indexOf('http://')==-1 && url.indexOf('https://')==-1)
				{
				if(url.charAt(0)!='/')
					{
					var cdnProvider=keonn.config.getProperty("cdnProvider");
					
					if(cdnProvider=='custom')
						{						
						if(window.customCalculateFinalUrl)
							{
							var retval=window.customCalculateFinalUrl(url,maxsize);
							
							if(retval!=null)
								{
								return retval;
								}
							}
						
						// files url, we need to append the token
						
						var token=this.getTokenFromUrl();
						
						url='/advancloud/publish/file/'+token+'/'+url;
						}
						else
					if(cdnProvider=='scene7')
						{
						var domain=getRandomFromScene7Server(url,false);
						
						var rurl=domain+url;
						
						return getScene7ActualParams(rurl,maxsize);
						}
						else
					if(cdnProvider=='alibaba')
						{
						var token=this.getTokenFromUrl();
						
						url='/advancloud/publish/file/'+token+'/'+url;
						}
						else
						{
						// files url, we need to append the token
						
						var token=this.getTokenFromUrl();
						
						url='/advancloud/publish/file/'+token+'/'+url;		
						}
					}
				
				var rurl=serverurl+url;
				
				if(maxsize && maxsize!='none' && maxsize!=0)
					return rurl+"?maxsize="+maxsize;
					else
					return rurl;		
				
				}
				else
				{
				// http or https detect google or weserv
					
				var cdnProvider=keonn.config.getProperty("cdnProvider");
					
				if(cdnProvider=='custom')
					{
					if(window.customCalculateFinalUrl)
						{
						var retval=window.customCalculateFinalUrl(url,maxsize);
						
						if(retval!=null)
							{
							return retval;
							}
						}
					}
					else
				if(cdnProvider=='alibaba' || url.indexOf(".aliyuncs.com/")!=-1) // alibaba
					{
					return url+"?x-oss-process=image/resize,l_"+maxsize;
					}
				
				var gdomain=this.getGoogleUrlDomainFromUrl(url);
				
				if(gdomain!=null)
					{
					var lh3Test=keonn.config.getProperty("lh3Test");
					
					if(lh3Test)
						{
						var toSingapore=function(url)
						{
						var kk=gdomain;
						var urlx=url.indexOf(kk);
						var ii=urlx+kk.length;
							
							return 'http://52.74.54.134/'+url.substring(ii);
						}
						
						if(maxsize)
							{
							if(maxsize=='none')
								return toSingapore(url);
								else
								return toSingapore(url+"=s"+maxsize);
							}
							else
							{
							return toSingapore(url+"=s1920");
							}
						}
											
					var mobifytest=keonn.config.getProperty("mobifyTest");
					
					if(mobifytest)
						{
						var servers=['ir1','ir2','ir3'];
						
						var getRandomFromUrl=function(urlxx,maxnum)
						{
							var hh=keonn.util.calculateHash(urlxx);

							hh=(Math.abs(hh))%maxnum;

							return hh;
						}			

						var rs=servers[getRandomFromUrl(url,servers.length)];
						var randomreserver="https://"+rs+".mobify.com/";
						
						if(maxsize)
							{
							if(maxsize=='none')
								return randomreserver+url;
								else
								return randomreserver+url+"=s"+maxsize;
							}
							else
							{
							return randomreserver+url+"=s1920";
							}
						}
						else
						{
						var allowWebp=keonn.config.getProperty("allowWebp",!isapple);
							
						if(maxsize)
							{
							if(maxsize=='none')
								return url;
								else
								return url+"=s"+maxsize+(allowWebp?"-rw":"");
							}
							else
							{
							return url+"=s1920"+(allowWebp?"-rw":"");
							}
						}
					}
					else
				if(url.indexOf('images.weserv.nl/')!=-1)
					{
					if(maxsize && maxsize!='none')
						{
						return url+"&w="+maxsize+"&h="+maxsize+"&t=fitup";
						}
						else
						{
						return url;
						}
					}	
					
				return url;
				}
		},
		
		validateEmailAddress: function(emailText){
			var pattern = /^[a-zA-Z0-9\-_]+(\.[a-zA-Z0-9\-_]+)*@[a-z0-9]+(\-[a-z0-9]+)*(\.[a-z0-9]+(\-[a-z0-9]+)*)*\.[a-z]{2,4}$/;
		    if (pattern.test(emailText)) {
		        return true;
		    } else {
		        return false;
		    }
		},
		
		calculateHash: function(obj){
			return value(obj);
		},
		
		indexOfHash: function(arr,obj){
			var vhash=this.calculateHash(obj);
			
			for(var i=0;i<arr.length;i++)
				{
				var ai=arr[i];
				var aih=this.calculateHash(ai);
				
				if(aih==vhash)
					{
					return i;
					}
				}
			
			return -1;
			
		},
		
		deepClone: function(obj){
			if(obj==null)
				return null;
			
			return JSON.parse(JSON.stringify(obj));
		},
		
		makeImmutable: function makeImmutable (obj) {
		    if ((typeof obj === "object" && obj !== null) ||
		        (Array.isArray? Array.isArray(obj): obj instanceof Array) ||
		        (typeof obj === "function")) {

		        Object.freeze(obj);

		        for (var key in obj) {
		            if (obj.hasOwnProperty(key)) {
		                makeImmutable(obj[key]);
		            }
		        }
		    }
		    
		    return obj;
		},
		
		currentTimeNow: function() {
		    return new Date().getTime();
		},
		
		debounce: function(func, wait, immediate) {
		    var timeout, args, context, timestamp, result;
		    var thiso=this;

		    var later = function() {
		      var last = thiso.currentTimeNow() - timestamp;

		      if (last < wait && last > 0) {
		        timeout = setTimeout(later, wait - last);
		      } else {
		        timeout = null;
		        if (!immediate) {
		          result = func.apply(context, args);
		          if (!timeout) context = args = null;
		        }
		      }
		    };

		    return function() {
		      context = this;
		      args = arguments;
		      timestamp = thiso.currentTimeNow();
		      var callNow = immediate && !timeout;
		      if (!timeout) timeout = setTimeout(later, wait);
		      if (callNow) {
		        result = func.apply(context, args);
		        context = args = null;
		      }

		      return result;
		    };
		  },
		  
		  throttle: function(func, wait, options) {
			  var thiso=this;
			    var context, args, result;
			    var timeout = null;
			    var previous = 0;
			    if (!options) options = {};
			    var later = function() {
			      previous = options.leading === false ? 0 : thiso.currentTimeNow();
			      timeout = null;
			      result = func.apply(context, args);
			      if (!timeout) context = args = null;
			    };
			    return function() {
			      var now = thiso.currentTimeNow();
			      if (!previous && options.leading === false) previous = now;
			      var remaining = wait - (now - previous);
			      context = this;
			      args = arguments;
			      if (remaining <= 0 || remaining > wait) {
			        if (timeout) {
			          clearTimeout(timeout);
			          timeout = null;
			        }
			        previous = now;
			        result = func.apply(context, args);
			        if (!timeout) context = args = null;
			      } else if (!timeout && options.trailing !== false) {
			        timeout = setTimeout(later, remaining);
			      }
			      return result;
			    };
	},
	
	
		rateLimit: function(fn,delay,maxitems){
			
			 var queue = [], timer = null;
			    
			 var thiso = this;
				
			  function processQueue() {
			    var item = queue[thiso.getClosureValue("shift")]();
			    if (item)
			      fn.apply(null,item.arguments);
			    if (queue.length === 0)
			      clearInterval(timer), timer = null;
			  }

			  var retval=function limited() {
			  
			  	if(!maxitems || queue.length<maxitems)
			  		{
			    	queue.push({
			      	arguments: [].slice.call(arguments)
			    	});
			    	if (!timer) {
			      	processQueue();  // start immediately on the first invocation
			      	timer = setInterval(processQueue, delay);
			    	}
			    	}
			  }
			  
			  retval.cleanTheRateQueue=function(){
				  queue.length=0;
			  };
			  
			  return retval;
		},
		
		executeJustOnceLaterAsMinitask: function(originalfunction)
		{

			var timeoutid=null;
			var thiso=null;
			var callparameters=null;

			return function(){

				if(timeoutid==null)
					{
					timeoutid=setTimeout(function(){
				
						originalfunction.apply(thiso,callparameters);

						timeoutid=null;
						thiso=null;
						callparameters=null;
				
						},0);			
					}
				
				thiso=this;
				callparameters=arguments;
				};
		},
		
		getClosureValue: function(kk){
			return ""+kk;
		},
		
		applyColorsForSelect: function(currentID)
		{
			var $el=$(currentID);
			
			$el.find("option:selected").each(function() {
					var selbackground=$(this).data('background');
					
					if(selbackground)
						{
						$(currentID + '-button').css('background',selbackground);
						}
				}); 
			
			$.each($(currentID).find('option'), function (index, element) {
				var background=$(element).data('background');
				
	            if (background) {
	                $(currentID + '-menu').children().eq(index).find('div').css('background',background);
	            }
	        });
		},
		
		isStringANumber: function(n)
		{
		  return !isNaN(parseFloat(n)) && isFinite(n);
		},
		
		formatDateTime: function(date)
		{
			  var hours = date.getHours();
			  var minutes = date.getMinutes();
			  var seconds= date.getSeconds();
			  hours = hours<10 ? '0' + hours : hours; 
			  minutes = minutes<10 ? '0'+minutes : minutes;
			  seconds = seconds<10 ? '0'+seconds : seconds;
			  var strTime = hours + ':' + minutes + ':' + seconds;
			  return date.getDate() + "/" + (date.getMonth()+1) + "/" + date.getFullYear() + "  " + strTime;
		},
		
		resolveAbsoluteUrl: function(base, url)
		{
		    var d = document.implementation.createHTMLDocument();
		    var b = d.createElement('base');
		    d.head.appendChild(b);
		    var a = d.createElement('a');
		    d.body.appendChild(a);
		    b.href = base;
		    a.href = url;
		    
		    return a.href;
		},
		
		getBase64Image: function (img) {
		    // Create an empty canvas element
		    var canvas = document.createElement("canvas");
		    canvas.width = img.width;
		    canvas.height = img.height;

		    // Copy the image contents to the canvas
		    var ctx = canvas.getContext("2d");
		    ctx.drawImage(img, 0, 0);

		    // Get the data-URL formatted image
		    return canvas.toDataURL("image/jpeg",0.8);
		},
		
		manageBackgroundImageLoad: function($el,url,urlfail)
		{
			var backimageid=keonn.util.randomStringAlpha(8);
			
			$el.attr("data-kbackimageid",backimageid);
			
			setTimeout(function(){
				loadBackgroundFromDom(backimageid,url,urlfail);
			},0);
		},
		
		isEmptyObject: function(obj) {
		
			for (var prop in obj)
			{
				return false;
			}
			
			return true;
		},
		
		waitForAllPromises: function(deferreds) {
			
			var toArray = function (args) { return deferreds.length > 1 ? $.makeArray(args) : [args[0]]; };
		
        	return $.Deferred(function (def) {
            	$.when.apply(jQuery, deferreds).then(
	                function () {
	                    def.resolveWith(this, [toArray(arguments)]);
	                },
	                function () {
	                    def.rejectWith(this, [toArray(arguments)]);
	                });
        		});
    			
		},
			
		unsignedArrayToHex: function (array) {
		    	var encodeLookup = '0123456789abcdef'.split('');
		    	  var length = array.length;
		    	  var string = '';
		    	  var c, i = 0;
		    	  while (i < length) {
		    	    c = array[i++];
		    	    string += encodeLookup[(c & 0xF0) >> 4] + encodeLookup[c & 0xF];
		    	  }
		    	  return string;
	    },
	    
	    processArraySerially: function(arr,objtopromise,onend,onitem)
	    {
	    	var len=arr.length;
	    	var count=0;
	    	var retval=[];
	    	
	    	var onItem=function(data){
	    		
	    		retval[count]=data;
	    			
	    		count++;
	    		
	    		if(count<len)
	    			{
	    			if(onitem)
		    			{
		    			onitem(data,retval.slice());
		    			}	
	    			
	    			objtopromise(arr[count]).then(onItem);
	    			}
	    			else
	    			{
	    			if(onend)
	    				{
	    				onend(retval.slice());	
	    				}
	    			}
	    	};
	    	
	    	if(len>0)
	    		{
	    		objtopromise(arr[count]).then(onItem);	
	    		}
	    },
	    
	    appendJavaScriptSourceTagToHeader: function(src)
	    {
	    	var javapositivehash=function(str){
	    		var hash = 0;
	    		
	    		    if (str.length == 0) return hash;
	    		
	    		    for (var i = 0; i < str.length; i++) {
	    		
	    		        var chara = str.charCodeAt(i);
	    		
	    		        hash = ((hash<<5)-hash)+chara;
	    		
	    		        hash = hash & hash; // Convert to 32bit integer
	    		    }
	    		
	    		    if(hash<0)
	    		    	{
	    		    	hash=-hash;
	    		    	}
	    		    
	    		    return hash;	    		
	    	};
	    	
	    	var javahash=javapositivehash(src);
			
			var funcname="functionclosureinline_"+javahash;
			
			if(window[funcname])
				{
				window[funcname].apply(window);
				}
				else
				{
				$('<script>')
		        .attr('type', 'text/javascript')
		        .attr('src', src)
		        .appendTo('head');
				}
	    },
	    
	    createTimeoutedPromise: function(promise,timeoutMillis)
	    {
	    	var timeout;

			var clearpromisetimeout = function()
			{
				clearTimeout(timeout);
			}
	    	
	    	var pr = Promise.race([
	        	promise,
	        	new Promise(function(resolve, reject) {
	          	timeout = setTimeout(function() {
	            	reject("timeout");
	          	}, timeoutMillis);
	        	}),
			]);

			pr.then(function()
			{
				clearpromisetimeout();
			});

			pr.catch(function()
			{
				clearpromisetimeout();
			});

			return pr;
	    },
	    
	    pluginTrigger: function(eventname,paramsarray)
		{
	    	kplugin.pluginTrigger(eventname,paramsarray);
		},
	    
	    pluginTriggerFast: function(eventname)
		{
	    	kplugin.pluginTriggerFast.apply(kplugin,arguments);	
		}
	};
})();

window['keonn']=keonn;
keonn['util']=keonn.util;
keonn.util['calculateFinalUrl']=keonn.util.calculateFinalUrl;
keonn.util[keonn.util.getClosureValue('appendJavaScriptSourceTagToHeader')]=keonn.util.appendJavaScriptSourceTagToHeader;
keonn.util[keonn.util.getClosureValue('formatTemplateWithObject')]=keonn.util.formatTemplateWithObject;
keonn.util[keonn.util.getClosureValue('getServerFromUrl')]=keonn.util.getServerFromUrl;
keonn.util[keonn.util.getClosureValue('toastld')]=keonn.util.toastld;



var kplugin=kplugin || (function(){
	
	var registeredons=new Set();
	
	var registereddirects={};
		
	var jqueryfn=$["fn"];
	
	var old = jqueryfn.on;

	jqueryfn.on = function(eventname) {
		
			this.each(function(idx,itm){
				
				if(itm===document)
					{					
					registeredons.add(eventname);		
					}
				
			});
		
		return old.apply(this, arguments);
		
	};
	
	return {
		registerPluginCallback: function(eventname,funct){
			
			registereddirects[eventname]=funct;
		},
		
		pluginTrigger: function(eventname,paramsarray)
		{
			if(registeredons.has(eventname))
				{
				$(document).triggerHandler(eventname,paramsarray);	
				}
	    	
			var cb=registereddirects[eventname];
			
			if(cb)
				{
				if(!paramsarray)
					{
					paramsarray=[];
					}
				
				cb.apply(window,[eventname].concat(paramsarray));
				
				/*var event=new Event(eventname, {});
		    	
		    	event["kparamsarray"]=paramsarray;
		    	
		    	document.dispatchEvent(event);
		    	*/	
				}
		},
		
		pluginTriggerFast: function(eventname)
		{
			/* no support for jquery triggers
			if(registeredons.has(eventname))
				{
				$(document).triggerHandler(eventname,paramsarray);	
				}
			*/
	    	
			var cb=registereddirects[eventname];
			
			if(cb)
				{
				cb.apply(window,arguments);	
				}
		}
	};
})();

window['kplugin']=kplugin;
